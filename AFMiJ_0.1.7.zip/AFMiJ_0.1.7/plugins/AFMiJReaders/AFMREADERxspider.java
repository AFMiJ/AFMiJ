/* Copyright 2022 Lorenzo Lunelli

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License. */



//----------------------------------------------------------------------
// ----------------- XMIPP/SPIDER reader -------------------------------
// 	v 0.4.0  4-07-2015 java conversion of jython version
//	v 0.4.1 16-12-2018 implemented as AFM reader plugin
//	v 0.4.2 01-09-2020 addedd Getversion method
//  v 0.4.3 02-09-2020 changed return codes to int
//	v 0.5.0 09-07-2021 changed name to 'AFMREADERxspider, added endianess detection
//	v 0.5.0a 20-03-2022 changed initial value of done to -1
// Lorenzo Lunelli
// passed parameters: file path, LUT dir, LUT name, lbl
//
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.lang.Math;

import ij.IJ;
import ij.ImagePlus;
import ij.ImageStack;
import ij.io.OpenDialog;
import ij.io.FileInfo;
import ij.io.FileOpener;
import ij.io.Opener;
import ij.plugin.PlugIn;
import ij.process.ImageProcessor;
import ij.process.LUT;
import ij.Macro;
import ij.measure.Calibration;


public class AFMREADERxspider {

	static FileInputStream fis = null;
	// ============  debug ===============
	static boolean de_bug = IJ.debugMode;
	// ============  debug ===============

	public static String Getversion() {
		String version="0.5.0a";
		return version;
	}

	public static int AFMiJread(String path,String lutdir,String lut,String lbl) {
		String known_formats,directory;
		String requires_version = "1.49v";
		String format=null;
		String sdatablock=null;
		int record =0;
		int done = -1;
		boolean littleendianess=false;
		
		boolean failure = IJ.versionLessThan(requires_version);
		if (failure) {
			return done;
		}
		
		// ============  debug ===============
		de_bug = IJ.debugMode;
		// ============  debug ===============

		dprint("**** Hello **** ", " This is the SPIDER Reader plugin.");
		known_formats="SPIDER (spid)";

		if (de_bug){
			IJ.log("*"+path+"*\n");
			IJ.log("*"+lutdir+"*\n");
			IJ.log("*"+lut+"*\n");
			IJ.log("*"+lbl+"*\n");
		}

		if (path.equals("")) {
			try {
				OpenDialog od = new OpenDialog("Choose a "+ known_formats+ " file", null);
				directory = od.getDirectory();
				path=directory + od.getFileName();
			} catch(Exception e){done=-1;return done;};
		}
		if (lut.equals("")) {lut="None";};

		byte[] datablock =  fileread(path,1024);
		if (datablock==null){
			return done;
		}
		try {
			sdatablock = new String(datablock, "US-ASCII");
		} catch (UnsupportedEncodingException e) {
		}
		dprint("^^^ trying to find the right format ... ^^^",known_formats);
		dprint("read string length is:",Integer.toString(sdatablock.length()));
		dprint("read string is",sdatablock);

		String fext=path.substring(path.lastIndexOf(".")+1);  // extracts the file extension
		done=-1; // not yet done
		if (fext.length()>0){
			dprint("file extension",fext);
			if (fext.toLowerCase().equals("xmp") || fext.toLowerCase().equals("spid")) {  // file is SPIDER
				format="spider";
				//------------------------ spider reader code -------------------------
				String imagename=null;
				String imagepath=null;
				// -----  image header parameters ---------------
				float dum,height,width,offset,iform,istack,labrec,maxim;
				FileInfo fi = null;
				FileOpener fo = null;
				ImagePlus imp = null;
				dprint("----------> in xmp/spider reader method","");
				String os_sep = System.getProperty("file.separator");
				dprint(os_sep," is the file separator ...");
				imagename=path.substring(path.lastIndexOf(os_sep)+1);
				imagepath=path.substring(0,path.lastIndexOf(os_sep));
				dprint("image path=",imagepath);
				dprint("image name=",imagename);
				//-------  check endianess ----------------------
				record=5;
				dum = rawtofloat(datablock,(record-1)*4,littleendianess);	// rec 5 file tye specifier
				if (dum!=1) { //we want this parameter to be 1. If not, then try to read parameners swapping endianess
					littleendianess=true;
				}
				if (littleendianess) {
					dprint("found little endianess","");
				} else {
					dprint("found big endianess","");
				}
				//============================================
				record=1;
				dum = rawtofloat(datablock,(record-1)*4,littleendianess);				// rec 1 number of planes in volume
				dprint("num slices=",Float.toString(dum));
				record=2;
				height = rawtofloat(datablock,(record-1)*4,littleendianess);			// rec 2 number of rows (NY)
				dprint("height=",Float.toString(height));
				record=5;
				iform = rawtofloat(datablock,(record-1)*4,littleendianess);				// rec 5 file type specifier
				dprint("iform=",Float.toString(iform));
				record=12;
				width = rawtofloat(datablock,(record-1)*4,littleendianess);				// rec 12 number of columns (NX)
				dprint("width=",Float.toString(width));
				record=13;
				labrec = rawtofloat(datablock,(record-1)*4,littleendianess);			// rec 13 number of records in file header
				dprint("labrec=",Float.toString(labrec));
				record=22;
				offset = rawtofloat(datablock,(record-1)*4,littleendianess);			// rec 22 labbyt
				dprint("offset=",Float.toString(offset));
				record=24;
				istack = rawtofloat(datablock,(record-1)*4,littleendianess);			// rec 24 ISTACK/MAXINDX
				dprint("istack=",Float.toString(istack));
				record=26;
				maxim = rawtofloat(datablock,(record-1)*4,littleendianess);				// rec 24 ISTACK/MAXINDX
				dprint("maxim=",Float.toString(maxim));
				if (iform==1) {	// only process 2D images (or stacks of 2D images)
					// step 2, read the image data using ImageJ functions
					// build the FileInfo structure (contains everything about the image... scale, units, format...)
					switch((int) Math.signum(istack)+1)
					{
						case 0: //istack negative: indexed stack of images
						float maxindx=Math.abs(istack);
						float indexrec= (float) Math.ceil(maxindx/width);
						IJ.showMessage("Indexed Stack of Images:\nNot Yet Supported");
						break;
						case 1: //istack zero: no stack
							fi = new FileInfo();
							fi.directory = imagepath;
							fi.fileName = imagename;
							fi.fileType = FileInfo.GRAY32_FLOAT;
							fi.fileFormat = FileInfo.RAW;
							fi.width = (int) width;
							fi.height = (int) height;
							fi.intelByteOrder = littleendianess;
							fi.nImages = 1;
							fi.offset = (int) offset;
							dprint ("Reading the image now...", "");
							fo = new FileOpener(fi);
							imp = fo.open(false);
							if (!lut.equals("None")){               // set the LUT
								LUT ijlut = Opener.openLut(lutdir+lut); 
								imp.getProcessor().setLut(ijlut);
							}
							if (lbl.equals("lbl")){
								AUTOLBL(imp,0);
							}
							imp.show();
							done = 1;
						break;
						case 2: //istack positive: stack of images
							IJ.showMessage("Stack of Images:\nNot Yet Supported");
							/*fi = new FileInfo();
							fi.directory = imagepath;
							fi.fileName = imagename;
							fi.fileType = FileInfo.GRAY32_FLOAT;
							fi.fileFormat = FileInfo.RAW;
							fi.width = (int) width;
							fi.height = (int) height;
							fi.intelByteOrder = littleendianess;
							fi.nImages = (int) maxim;
							fi.offset = (int) offset;
							dprint ("Reading the image now...", "");
							fo = new FileOpener(fi);
							imp = fo.open(false);
							if (!lut.equals("None")){               // set the LUT
								LUT ijlut = Opener.openLut(lutdir+lut); 
								imp.getProcessor().setLut(ijlut);
							}
							if (lbl.equals("lbl")){
								AUTOLBL(imp,0);
							}
							imp.show();
							done=1;*/
						break;
					} // end switch
				}// end if image format is 2D
				
			}
		}
		return done;
	} // ********************** END READ ***********************************


	// ========================= FUNCTIONS =============================
	//
	//
	//
	static void AUTOLBL (ImagePlus imp, int slice){
	//   v 0.4.0 12-7-2015 java conversion of jython  # v 0.3.1 24-5-2013 - modified to handle stacks	
		int nlines,npoints,stacksize;
		float mean;
		float [] data=null;
		float[] pix;
		ImageProcessor ip=null;			// define here the image structures 
		ImageStack stack =null;
		
		dprint("in autolbl plugins","");
		dprint ("slice is:",Integer.toString(slice));
		nlines=imp.getHeight();
		dprint ("nlines=",Integer.toString(nlines));
		npoints= imp.getWidth();
		dprint ("npoints=",Integer.toString(npoints));
		stacksize = imp.getImageStackSize();
		dprint("INFO slice is "+slice,", stack size is "+stacksize );
		if (slice>stacksize){
			IJ.log("error slice is "+slice+", stack size is "+stacksize);
			return;
		}
		if (stacksize==1) {   // no stack
			ip = imp.getProcessor();
			dprint("acquiring data from no stack","");
		} else {
			stack = imp.getImageStack();		// stack
			ip = stack.getProcessor(slice);
			dprint("acquiring data from stack size=",Integer.toString(stacksize));
		}
		for (int y=0;y<nlines;y++){
			mean=0;
			data = ip.getRow(0, y, data, npoints);
			for (int x=0;x<data.length;x++){
				mean=mean+data[x];
			}
			mean=mean/npoints;
			for (int x=0;x<data.length;x++){
				data[x]=data[x]-mean;
			}
			ip.putRow(0, y, data, npoints);
		}
	}


	static void dprint(String arg1, String arg2){
		if (de_bug){
			IJ.log("*"+arg1+"*    *"+arg2+"*");
		}
	}

	static float rawtofloat(byte[] raw,int offset, boolean littleendianess){
		ByteBuffer buffer = ByteBuffer.wrap(raw,offset,4);
		if (littleendianess) {
			return buffer.order(ByteOrder.LITTLE_ENDIAN).getFloat();
		} else {
			return buffer.order(ByteOrder.BIG_ENDIAN).getFloat();
		}
	}

	static byte[] fileread(String InputFileName, int numbytes){   // numbytes=0 means to the end of the file, if numbytes exceeds the file length, the file is read to the end.
		FileInputStream fis = null;
		byte[] buf = null;
		int length;
      	try {
			try {
				fis = new FileInputStream(InputFileName);
				length = Math.min(fis.available(),numbytes);
				if (numbytes==0){
					length=fis.available();
				}
				dprint("bytes to read are: ",Integer.toString(length));
				buf = new byte[length];
				fis.read(buf);
			}
			finally {
				// releases all system resources from the streams
				if(fis!=null) {
            		fis.close();
				}
			}
		}
    	catch(FileNotFoundException ex){
    	}
    	catch(IOException ex){
    	}
		return buf;
	}
}
