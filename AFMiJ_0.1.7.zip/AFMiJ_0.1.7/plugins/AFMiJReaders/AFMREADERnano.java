/* Copyright 2022 Lorenzo Lunelli

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License. */



//----------------------------------------------------------------------
// ----------------- nanoscope file reader -------------------------------
//  v alpha 0.0.1 31-10-2018 - first version
//  v alpha 0.0.2 18-11-2018 - added "Ciao scan list" reading
//  v alpha 0.0.3 18-01-2019 - implemented as reader plugin
//  v alpha 0.0.4 01-09-2020 addedd Getversion method
//  v alpha 0.0.5 02-09-2020 changed return codes to int
//  v alpha 0.0.6 06-04-2021 corrected bug in scaling data
//  v alpha 0.0.7 02-08-2021 set the "AFMiJ" property and Z units as Label
//  v alpha 0.0.7a 20-03-2022 changed initial value of done to -1
// Lorenzo Lunelli

// passed parameters: file path, LUT dir, LUT name, lbl
//
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.lang.Math;

import ij.IJ;
import ij.ImagePlus;
import ij.ImageStack;
import ij.io.OpenDialog;
import ij.io.FileInfo;
import ij.io.FileOpener;
import ij.io.Opener;
import ij.plugin.PlugIn;
import ij.process.ImageProcessor;
import ij.process.LUT;
import ij.Macro;
import ij.measure.Calibration;



public class AFMREADERnano {

	static FileInputStream fis = null;
	// ============  debug ===============
	static boolean de_bug = IJ.debugMode;
	// ============  debug ===============

	public static String Getversion() {
		String version="alpha 0.0.7a";
		return version;
	}

	public static int AFMiJread(String path,String lutdir,String lut,String lbl) {
		String known_formats,directory;
		String requires_version = "1.49v";
		String format=null;
		String sdatablock=null;
		int done = -1;
		
		String par,val;
		String pattern=null;
		String dummy=null;
		String header=null;
		String scanlist=null;
		String os_sep = System.getProperty("file.separator");
		String fileimagename=path.substring(path.lastIndexOf(os_sep)+1);
		String imagepath=path.substring(0,path.lastIndexOf(os_sep));
		String filestring=null;
		boolean zheight = false;
		boolean other = false;
		int ki;
		ImagePlus ii;
		Calibration calunits = new Calibration();
		
		String [] lines,sublines;
		String [] scales,info;
		String datatypeline,datatype,hardtype,hardvalue,imagedata;
		String infopattern,infostring;
		int dataindex,dataindex1,dataindex2,dataindex3,dataindex4,dataindex5,dataindex6;
		int dataindexend,dataindexend1,dataindexend3,dataindexend4,dataindexend5;
		int start, images_in_group;
		char eol=(char) 10;
		String Unit,Scale,finUnit,unit_xy;
		double Value,conversion,xy_size;
		
		double SensZScan;
		String SensZScanScale;
		double SensAmplitude;
		String SensAmplitudeScale;
		double SensPhase;
		String SensPhaseScale;
		
		boolean failure = IJ.versionLessThan(requires_version);
		if (failure) {
			return done;
		}
		
		
		// ============  debug ===============
		de_bug = IJ.debugMode;
		// ============  debug ===============
		String format_id="nano";
		dprint("**** Hello **** ", " This is the " + format_id +" plugin.");
		known_formats=format_id;

		if (de_bug){
			IJ.log("*"+path+"*\n");
			IJ.log("*"+lutdir+"*\n");
			IJ.log("*"+lut+"*\n");
			IJ.log("*"+lbl+"*\n");
		}

		if (path.equals("")) {
			OpenDialog od = new OpenDialog("Choose a "+ known_formats+ " file", null);
        	directory = od.getDirectory();
        	path=directory + od.getFileName();
		}
		if (lut.equals("")) {lut="None";};

		byte[] hdatablock =  fileread(path,256);
		if (hdatablock==null){
			return done;
		}
		try {
			sdatablock = new String(hdatablock, "US-ASCII");
		} catch (UnsupportedEncodingException e) {
		}
		dprint("^^^ trying to find the right format ... ^^^",known_formats);
		dprint("read string length is:",Integer.toString(sdatablock.length()));
		dprint("read string is",sdatablock);
		
		
		String [] sdatalines = sdatablock.replace(Character.toString((char) 00), "").split("\\x0A");
		//  -> take the first line (index=0)
		String firstline = sdatalines[0].trim();
		dprint ("first line=", firstline);
		
		
// 		Step 0, identify the file format
		if (firstline.equals("\\*File list")) {
			if (sdatalines.length>1){ // there is a second line
			//  -> take the second line (index=1)
			String secondline = sdatalines[1].trim();
			dprint ("second line=", secondline);
				if(secondline.split(":").length>1){
					par = secondline.split(":")[0].trim();
					val = secondline.split(":")[1].trim();
					dprint("number of elements in second line is:",Integer.toString(secondline.split(":").length));
					dprint("[0]=",par);
					dprint("[1]=",val);
					if (par.equals("\\Version")) {
						val = val.substring(3,7);
						int nval = Integer.parseInt(val);
						dprint("Nanoscope version is: ", String.valueOf(nval));
						if (nval >= 4310) {  // ok Nanoscope v 4.31 or newer
							dprint("Nanoscope version is: ", String.valueOf(nval));
							format="nanoscope";
							dprint("----------> in nanoscope reader method","");
							IJ.showMessage("---- WARNING ----","THIS READER IS ALPHA SOFTWARE");
							List<Integer> indexCiao = new ArrayList<Integer>();
							List<Integer> bytes = new ArrayList<Integer>();
							List<Integer> dataoffset = new ArrayList<Integer>();
							List<Integer> datalength = new ArrayList<Integer>();
							List<Integer> xres = new ArrayList<Integer>();				// xres contains number of columns
							List<Integer> yres = new ArrayList<Integer>();				// yres contains number of rows
							List<String> softscaletype = new ArrayList<String>();		// type of softscale
							List<Double> hardScale = new ArrayList<Double>();			// hard scale conversion factor
							List<Double> hardValue = new ArrayList<Double>();			// hard value
							List<String> imageData = new ArrayList<String>();			// image data type
							List<String> softUnit = new ArrayList<String>();			// units of the softscale (e.g "V")
							List<Double> softScale = new ArrayList<Double>();			// softscale conversion factor
							List<String> softScaleUnit = new ArrayList<String>();		// scale units of the softscale (e.g. "nm/V", "nA/V" - null if not set)
							List<String> softScaleFinalUnit = new ArrayList<String>();	// final scale units of the image (e.g. "nm", "nA" - null if not set)
							List<String> ImageNote = new ArrayList<String>();
							List<ImagePlus> ImageImp = new ArrayList<ImagePlus>();
							List<Integer> ptr = new ArrayList<Integer>();  				// pointer to the data in the data lists
							
							// check lists below
							List<Integer> metaindex = new ArrayList<Integer>();
							List<Integer> group = new ArrayList<Integer>();			// the group number
							List<Double> xreal = new ArrayList<Double>();
							List<Double> yreal = new ArrayList<Double>();
							//List<String> unit_xy = new ArrayList<String>();
							List<String> unit_z = new ArrayList<String>();
							List<String> title = new ArrayList<String>();
							List<String> slicelabel = new ArrayList<String>();
							
							dprint ("start of nanoscope file",path);
							byte[] datablock =  fileread(path,0);
							try {
								filestring = new String(datablock, "US-ASCII");
							} catch (UnsupportedEncodingException e) {
							}
							pattern = "\\*File list end";
							dataindex = filestring.indexOf(pattern);
							dprint(Integer.toString(dataindex),pattern);
							header = filestring.substring(0,dataindex);
							dprint("header is:",header);

							// 0: read parameters form the \*Ciao scan list
							pattern="\\*Ciao scan list";
							xy_size=0;
							if ((header.indexOf(pattern))>-1) {
									dataindex=header.indexOf(pattern);
									dataindexend = header.indexOf("\\*",dataindex+1);
									if (dataindexend>-1){
										dataindexend--;
										scanlist=header.substring(dataindex,dataindexend);
										pattern="\\Scan size";
										dataindex1=scanlist.indexOf(pattern);
										dataindexend1=scanlist.indexOf(eol,dataindex1);
										dummy=scanlist.substring(dataindex1,dataindexend1);
										lines = dummy.split(":");  // e.g. " 2000 nm"
										sublines = lines[1].trim().split(" ");
										xy_size = Float.parseFloat(sublines[0].trim());
										unit_xy = sublines[1].trim();
										dprint("xy units are: "+unit_xy,String.valueOf(xy_size));
										if (unit_xy.equals("m")) {
											xy_size = xy_size*1e9;
										}
									}
							}
							
							// ===============1: read Ciao lists ====================
							boolean stay=true;
							start = 0;
							while (stay) {
								pattern="\\*Ciao image list";
								if ((header.indexOf(pattern,start))>-1) {
									dataindex=header.indexOf(pattern,start);
									indexCiao.add(dataindex);
									start = header.indexOf(eol,dataindex);
									dprint ("^^^^^^^^^^ offset is ^^^^^^^^^^^^^^",String.valueOf(start));
									pattern="\\Data offset"; //  ========================== data offset
									dataindex = header.indexOf(pattern,start);
									dataindexend = header.indexOf(eol,dataindex);
									dummy = header.substring(dataindex,dataindexend);
									lines = dummy.split(":");
									dprint("offset=",lines[0]);
									dataoffset.add(Integer.parseInt(lines[1].trim()));
									dprint("data offset=",String.valueOf(Integer.parseInt(lines[1].trim())));
									pattern="\\Data length"; //  ========================== data length
									dataindex = header.indexOf(pattern,start);
									dataindexend = header.indexOf(eol,dataindex);
									dummy = header.substring(dataindex,dataindexend);
									lines = dummy.split(":");
									datalength.add(Integer.parseInt(lines[1].trim()));
									dprint("data length=",String.valueOf(Integer.parseInt(lines[1].trim())));
									pattern="\\Bytes/pixel"; //  ========================== bytes per pixel
									dataindex = header.indexOf(pattern,start);
									dataindexend = header.indexOf(eol,dataindex);
									dummy = header.substring(dataindex,dataindexend);
									lines = dummy.split(" ");
									bytes.add(Integer.parseInt(lines[1].trim()));
									dprint("bytes/pixel=",String.valueOf(Integer.parseInt(lines[1].trim())));
									pattern="\\Samps/line"; //  ========================== xres
									dataindex = header.indexOf(pattern,start);
									dataindexend = header.indexOf(eol,dataindex);
									dummy = header.substring(dataindex,dataindexend);
									lines = dummy.split(":");
									xres.add(Integer.parseInt(lines[1].trim()));
									dprint("xres=",String.valueOf(Integer.parseInt(lines[1].trim())));
									pattern="\\Number of lines"; //  ========================== yres
									dataindex = header.indexOf(pattern,start);
									dataindexend = header.indexOf(eol,dataindex);
									dummy = header.substring(dataindex,dataindexend);
									lines = dummy.split(":");
									yres.add(Integer.parseInt(lines[1].trim()));
									dprint("yres=",String.valueOf(Integer.parseInt(lines[1].trim())));
									pattern="\\Note"; // ========================== Notes
									dataindex = header.indexOf(pattern,start);
									dataindexend = header.indexOf(eol,dataindex);
									dummy = header.substring(dataindex,dataindexend);
									lines = dummy.split(": ");
									if (lines.length > 1) {
										if (lines[1].trim().length()>0) {
											ImageNote.add(lines[1].trim());
										}
									}// else {
									//	ImageNote.add(null);
									//}
									dprint("Image Note",lines[1].trim());

					// find which  kind of data are in this image
					// search for the "Z scale: " pattern
									boolean stayhere = true;
									boolean stayhere1 =true;
									boolean stayhere2 =true;
									int startfrom = start;
									pattern="\\@"; //
									while (stayhere) {
										dataindex1 = header.indexOf(pattern,startfrom);
										if (dataindex1 !=-1) {
											dataindexend1 = header.indexOf(eol,dataindex1);
											datatypeline = header.substring(dataindex1,dataindexend1);
											dprint("datatypeline is:",datatypeline);
											dataindex2 = datatypeline.indexOf("Z scale: ");
											if (dataindex2 !=-1) {
												stayhere1 = false;
												// find soft unit type
												dataindex3 = datatypeline.indexOf("[");
												dataindexend3 = datatypeline.indexOf("]");
												datatype = datatypeline.substring(dataindex3+1,dataindexend3);
												softscaletype.add(datatype);
												dprint("datatype=",datatype);
												// find hard scale
												dataindex4 = datatypeline.indexOf("(");
												dataindexend4 = datatypeline.indexOf(")");
												hardtype = datatypeline.substring(dataindex4+1,dataindexend4).trim();
												//Value=Double.valueOf(hardtype.split(" ")[0]);
												dprint("hard scale number=",hardtype.split(" ")[0]); //qq
												dprint("hard scale units=",hardtype.split(" ")[1]); // qq
												Value=Float.parseFloat(hardtype.split(" ")[0]);
												hardScale.add(Value);
												dprint("hard scale=",String.valueOf(Value));
												// find hard value
												dataindex5=dataindexend4+1;
												dataindexend5 = datatypeline.length();
												hardvalue = datatypeline.substring(dataindex5,dataindexend5).trim();
												dprint("hard value string=",hardvalue);
												Value=Float.parseFloat(hardvalue.split(" ")[0]);
												dprint("hard value=",String.valueOf(Value));
												hardValue.add(Value);
											}
											// now search data type (Amplitude, Height,...)
											dataindex6 = datatypeline.indexOf("Image Data: ");
											if (dataindex6 !=-1) {
												stayhere2 = false;
												dataindex4 = datatypeline.indexOf("[");
												dataindexend4 = datatypeline.indexOf("]");
												imagedata = datatypeline.substring(dataindex4+1,dataindexend4).trim();
												dprint("image data=",imagedata);
												imageData.add(imagedata);
											}
											startfrom = dataindexend1; // go on starting from this new base offset
										}
										stayhere = stayhere1 || stayhere2; // check if is at the right line
									}
								} else {
									stay=false;
								}
								if (de_bug) ij.IJ.showMessage("wait");
							}
							// =================== end of Ciao lists ======================

							// 2) ========= iterate over the ciao list to find the softscale values ===
							for (int k=0;k<indexCiao.size();k++) {
								pattern="\\@"+softscaletype.get(k); // possible values are e.g. \@Sens. Zscan, \@Sens. Amplitude, \@Sens. Phase, \@Sens. Current
								dataindex = header.indexOf(pattern);
								softUnit.add(null);				// e.g. "V"
								softScale.add(null);			// e.g. "12.95302"
								softScaleUnit.add(null);		// e.g. "nm/V" or "nA/V" or ""
								softScaleFinalUnit.add(null);	// e.g. "nm" or "nA" or "a.u."
								if (dataindex!=-1) {
									dataindexend = header.indexOf(eol,dataindex);
									dprint("dataindex is:", String.valueOf(dataindex));
									dprint("dataindexend is:", String.valueOf(dataindexend));
									dummy = header.substring(dataindex,dataindexend);
									dprint(pattern + " is:", dummy);
									lines = dummy.split(":");
									dummy=lines[1].trim();
									scales=dummy.split(" ");
									Unit = scales[0].trim();
									Value = Float.parseFloat(scales[1].trim());
									dprint("length is: ",String.valueOf(scales.length));
									finUnit = "a.u.";
									if (scales.length == 3) {
										Scale = scales[2].trim();
										if (Scale.split("/").length>0) {
											finUnit=Scale.split("/")[0].trim();
										}
									} else {
										Scale=null;
									}
									softUnit.set(k,Unit);
									softScale.set(k,Value);
									softScaleUnit.set(k,Scale);
									softScaleFinalUnit.set(k,finUnit);
									dprint("Unit: ",Unit);
									dprint("Value: ",String.valueOf(Value));
									dprint("Scale: ",Scale);
								}
							}

							// 3) ========= now reading image info =====
							dprint("--- NOW","reading the image info ---");
							infopattern="Date";
							pattern="\\"+infopattern;
							if ((header.indexOf(pattern))>-1) {
								dataindex=header.indexOf(pattern);
								dataindexend=header.indexOf(eol,dataindex);
								infostring=header.substring(dataindex,dataindexend);
								info=infostring.split(": ");
								if (info.length > 1) {
									dprint(infopattern,info[1].trim());
									ImageNote.add(infopattern+":"+info[1].trim());
								}
							}
							//------------------------------------------------------
							infopattern="Microscope";
							pattern="\\"+infopattern;
							if ((header.indexOf(pattern))>-1) {
								dataindex=header.indexOf(pattern);
								dataindexend=header.indexOf(eol,dataindex);
								infostring=header.substring(dataindex,dataindexend);
								info=infostring.split(":");
								if (info.length > 1) {
									dprint(infopattern,info[1].trim());
									ImageNote.add(infopattern+":"+info[1].trim());
								}
							}
							//------------------------------------------------------
							infopattern="Scanner type";
							pattern="\\"+infopattern;
							if ((header.indexOf(pattern))>-1) {
								dataindex=header.indexOf(pattern);
								dataindexend=header.indexOf(eol,dataindex);
								infostring=header.substring(dataindex,dataindexend);
								info=infostring.split(":");
								if (info.length > 1) {
									dprint(infopattern,info[1].trim());
									ImageNote.add(infopattern+":"+info[1].trim());
								}
							}
							//------------------------------------------------------
							infopattern="Controller";
							pattern="\\"+infopattern;
							if ((header.indexOf(pattern))>-1) {
								dataindex=header.indexOf(pattern);
								dataindexend=header.indexOf(eol,dataindex);
								infostring=header.substring(dataindex,dataindexend);
								info=infostring.split(":");
								if (info.length > 1) {
									dprint(infopattern,info[1].trim());
									ImageNote.add(infopattern+":"+info[1].trim());
								}
							}
							//------------------------------------------------------
							infopattern="Piezo size";
							pattern="\\"+infopattern;
							if ((header.indexOf(pattern))>-1) {
								dataindex=header.indexOf(pattern);
								dataindexend=header.indexOf(eol,dataindex);
								infostring=header.substring(dataindex,dataindexend);
								info=infostring.split(":");
								if (info.length > 1) {
									dprint(infopattern,info[1].trim());
									ImageNote.add(infopattern+":"+info[1].trim());
								}
							}
							//------------------------------------------------------
							infopattern="Scan rate";
							pattern="\\"+infopattern;
							if ((header.indexOf(pattern))>-1) {
								dataindex=header.indexOf(pattern);
								dataindexend=header.indexOf(eol,dataindex);
								infostring=header.substring(dataindex,dataindexend);
								info=infostring.split(":");
								if (info.length > 1) {
									dprint(infopattern,info[1].trim());
									ImageNote.add(infopattern+":"+info[1].trim());
								}
							}


							// 4) ========= iterate over the ciao list and read the images =====
							images_in_group=0;
							for (int k=0;k<indexCiao.size();k++) {
								if (bytes.get(k)==2) { // at the moment, only works with 16 bits images
									FileInfo fi = new FileInfo();
									fi.directory = imagepath;
									fi.fileName = fileimagename;
									fi.fileType = FileInfo.GRAY16_SIGNED;
									fi.fileFormat = FileInfo.RAW;
									fi.width = xres.get(k);
									fi.height = yres.get(k);
									fi.intelByteOrder = true;
									//fi.intelByteOrder = intelmode;
									fi.unit = softScaleFinalUnit.get(k);
									//fi.valueUnit=unit_z.get(d);
									fi.pixelWidth = xy_size/(double) xres.get(k);
									fi.pixelHeight = xy_size/(double) yres.get(k);
									//fi.info = title.get(d);
									fi.info="";
									for (int j=0;j<ImageNote.size();j++) {
										fi.info = fi.info+ImageNote.get(j)+"\n";
										dprint("--->",ImageNote.get(j));
									}
									fi.nImages = 1;
									fi.offset = dataoffset.get(k);
									dprint ("Reading the image...", String.valueOf(k));
									FileOpener fo = new FileOpener(fi);
									ImagePlus imp = fo.openImage();
									//imp.show();
									ImageImp.add(imp);	// add the loaded image plus to the imageplus list
									ptr.add(k);  // this var points to the correct element in the data lists
									images_in_group++;
									ImageProcessor ip = imp.getProcessor().convertToFloatProcessor();    // we want floating point images
									imp.setProcessor(ip);
									//conversion=hardScale.get(k)*softScale.get(k); // probably wrong
									conversion=softScale.get(k)*hardValue.get(k)/65536; // try this
									if (fi.unit=="m") {  // if units are m, convert data to nm
										conversion=conversion*1.0e9;
										softScaleFinalUnit.set(k,"nm");
									}
									dprint("conversion is=",String.valueOf(conversion));
									imp.getProcessor().multiply(conversion);       // apply the bits to nm conversion
									imp.getProcessor().resetMinAndMax();
									imp.getProcessor().flipVertical(); // images seem to be inverted
								}
							}

							
							// 5) ========= now building the group =====
							dprint("========== now building the group... ==============","");
							ImageStack stack = ImageImp.get(0).createEmptyStack();
							ImagePlus stackimp = ImageImp.get(0).duplicate();  // duplicate the image (also cal., info etc.)
							for (int i=0;i<images_in_group;i++) {
								ki = ptr.get(i); // retrieve the data index that points to the initial list
								if (bytes.get(ki)==2) {
									dprint ("adding slice ",String.valueOf(ki));
									ii=ImageImp.get(ki);	// retrieve ImagePlus from list
									//dprint("info is ",ii.getInfoProperty());
									//dprint ("slice width ",String.valueOf(ii.getWidth()));
									//dprint ("slice height",String.valueOf(ii.getHeight()));
									stack.addSlice(ii.getProcessor());
									stack.setSliceLabel(imageData.get(ki)+" Z/"+softScaleFinalUnit.get(ki),i+1); // set slice Z units
									ii.close();
									if (softScaleFinalUnit.get(ki).equals("nm")) {
										zheight = true;
									} else {
										other = true;
									}
								}
							}
							stackimp.setStack(fileimagename,stack); //put the stack into the previuously duplicated imageplus
							stackimp.setProp("AFMiJ","yes");		// AFM image

							if (zheight && other) { // mixed data
								// we need to set the calibration to put the correct units
								ki = ptr.get(0);
								calunits.setValueUnit("a.u.");
								calunits.pixelWidth = xy_size/(double) xres.get(ki);
								calunits.pixelHeight = xy_size/(double) yres.get(ki);
								calunits.setXUnit("nm");
								calunits.setYUnit("nm");
								stackimp.setCalibration(calunits);
							}

						//	for (index=1;index<=stackimp.getNSlices();index++){

						//	}


							stackimp.show();
							done = 1;
						}
						else {
							done=-1;
						}
					}
				}
			}
		}
		
		return done;
	} // ********************** END READ ***********************************




	// ========================= FUNCTIONS =============================
	//
	//
	//
	static void AUTOLBL (ImagePlus imp, int slice){
	//   v 0.4.0 12-7-2015 java conversion of jython  # v 0.3.1 24-5-2013 - modified to handle stacks	
		int nlines,npoints,stacksize;
		float mean;
		float [] data=null;
		float[] pix;
		ImageProcessor ip=null;			// define here the image structures 
		ImageStack stack =null;
		
		dprint("in autolbl plugins","");
		dprint ("slice is:",Integer.toString(slice));
		nlines=imp.getHeight();
		dprint ("nlines=",Integer.toString(nlines));
		npoints= imp.getWidth();
		dprint ("npoints=",Integer.toString(npoints));
		stacksize = imp.getImageStackSize();
		dprint("INFO slice is "+slice,", stack size is "+stacksize );
		if (slice>stacksize){
			IJ.log("error slice is "+slice+", stack size is "+stacksize);
			return;
		}
		if (stacksize==1) {   // no stack
			ip = imp.getProcessor();
			dprint("acquiring data from no stack","");
		} else {
			stack = imp.getImageStack();		// stack
			ip = stack.getProcessor(slice);
			dprint("acquiring data from stack size=",Integer.toString(stacksize));
		}
		for (int y=0;y<nlines;y++){
			mean=0;
			data = ip.getRow(0, y, data, npoints);
			for (int x=0;x<data.length;x++){
				mean=mean+data[x];
			}
			mean=mean/npoints;
			for (int x=0;x<data.length;x++){
				data[x]=data[x]-mean;
			}
			ip.putRow(0, y, data, npoints);
		}
	}


	static void dprint(String arg1, String arg2){
		if (de_bug){
			IJ.log("*"+arg1+"*    *"+arg2+"*");
		}
	}

	
	static byte[] fileread(String InputFileName, int numbytes){   // numbytes=0 means to the end of the file, if numbytes exceeds the file length, the file is read to the end.
		FileInputStream fis = null;
		byte[] buf = null;
		int length;
      	try {
			try {
				fis = new FileInputStream(InputFileName);
				length = Math.min(fis.available(),numbytes);
				if (numbytes==0){
					length=fis.available();
				}
				dprint("bytes to read are: ",Integer.toString(length));
				buf = new byte[length];
				fis.read(buf);
			}
			finally {
				// releases all system resources from the streams
				if(fis!=null) {
            		fis.close();
				}
			}
		}
    	catch(FileNotFoundException ex){
    	}
    	catch(IOException ex){
    	}
		return buf;
	}
}
