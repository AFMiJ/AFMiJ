/* Copyright 2023 Lorenzo Lunelli

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License. */

//	v 0.1  03-08-2023
//	v 0.1a 28-08-2023 added reset method
//	v 0.1b 19-10-2023 added more table entries (slice number, slice label)
// implement all table functions in this file ? (at the moment tables and files are managed in macro language)

public class AFMiJlog {
	//private static String row;
	private static String logFilename;
	private static String logImage="";
	private static String logEvent="";
	private static String logValue="";
	private static String logSlice="";
	private static String logLabel="";

	private static String separator=Character.toString((char) 10);

	public static int set (String type, String data) {
		int back = -1;
		if (type.equals("name")) {
			logImage=logImage+separator+data;
			back = 1;
		} else if (type.equals("event")) {
			logEvent=logEvent+separator+data;
			back = 1;
		} else if (type.equals("value")) {
			logValue=logValue+separator+data;
			back = 1;
		} else if (type.equals("slice #")) {
			logSlice=logSlice+separator+data;
			back = 1;
		} else if (type.equals("slice label")) {
			logLabel=logLabel+separator+data;
			back = 1;
		} else if (type.equals("logfilename")) {
			logFilename=data;
			back = 1;
		}
		return back;
	}

	public static String get (String type) {
		String back="";
		if (type.equals("name")) {
			back=logImage;
		} else if (type.equals("event")) {
			back=logEvent;
		} else if (type.equals("value")) {
			back=logValue;
		} else if (type.equals("slice #")) {
			back=logSlice;
		} else if (type.equals("slice label")) {
			back=logLabel;
		} else if (type.equals("logfilename")) {
			back = logFilename;
		}
		return back;
	}

	public static int reset () {
		int back = -1;
		logImage="";
		logEvent="";
		logValue="";
		logSlice="";
		logLabel="";
		back = 1;
		return back;
	}
}
