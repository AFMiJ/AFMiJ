/* Copyright 2022 Lorenzo Lunelli

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License. */


//  ----- Jython versions ------------------------
// v 0.1
// v 0.2 - 27-5-2013 - added check (if file exists ask for another name) - makes use of OriginalFileInfo structure to retrieve image info
// v 0.3 - 15-5-2015 - removed a bug in the conversion of rescaled images (pixel dimensions were taken from the original image, not the rescaled one)
// v0.4p  -  4-6-2015 - compatible with ImageJ 2
//  -----  Java versions -------------------------
//  v0.5 - first java conversion
//	v0.5.1 - improved management of images without file name
//	v0.5.2 - optimized output code, debug state from ImageJ option
//  v0.5.2a 23-07-2019 - small optimization
//  v0.5.3 10-10-2020 - removed a bug when exporting an image loaded from a device that is then ejected
//  v0.5.4 04-07-2021 - added end message when not called in BatchMode, added better management of Z units

import ij.IJ;
import ij.ImagePlus;
import ij.io.SaveDialog;
import ij.io.FileInfo;
import ij.plugin.filter.PlugInFilter;
import ij.process.ImageProcessor;
import ij.macro.Interpreter;
import ij.ImageStack;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;


public class _bcrf_Export implements PlugInFilter {
	protected ImagePlus image;
	private boolean de_bug,askuser,writeit;
	private int width,height;
	private double pw,ph;
	private String info,dir,directory,filename,savename,newname,message,noext,header,spipheader,ZUnits,slicelabel,sliceZunit;
	private String [] dum;
	private byte[] someBytes,FileBytes;
	private byte headerBytes[] = new byte[2048];
	private float[] pix;
	private float value;
	private File ff,od;

	
	public int setup(String arg, ImagePlus image) {
		this.image = image;
		return NO_CHANGES | DOES_32 | NO_UNDO;
	}

	
	public void run(ImageProcessor ip) {
		
		de_bug=false;
		// ============  debug ===============
		de_bug = IJ.debugMode;		
		// ============  debug ===============

		FileInfo  ofi=image.getOriginalFileInfo();
		if (ofi!=null) {
			info = ofi.info;
			dir= ofi.directory;        // case A - standard FileInfo structure
			filename = ofi.fileName;
		}	else {
      		info="";
			dir=null;
			filename=null;
		}

		FileInfo fi=image.getFileInfo();  // java version
		width=fi.width;
		height=fi.height;
		pw = fi.pixelWidth;
		ph = fi.pixelHeight;

		askuser=false; // no need to ask the user for filename
		writeit=true;  // we want to write the output file

		if (dir==""){              // case B - trying to recover a misformed FileInfo structure
   			//dum=filename.split(".",1)
			noext=filename.substring(filename.lastIndexOf(".")+1);
    	//	noext=dum[0];
    		//dum=noext.rsplit(os.sep,1)
			dir=noext.substring(1,noext.lastIndexOf("/"));
    		filename=noext.substring(noext.lastIndexOf("/")+1);
		}
		if (dir==null){            // case C - no way - we need to ask the user
    		dir="";
    		askuser=true;
    		message="Select a file name";
		}

		if (de_bug) {
			IJ.log("------- file info -------");
   			IJ.log("XYunits "+fi.unit);
			IJ.log("Zunit "+fi.valueUnit);
  			IJ.log("info "+info);
  			IJ.log("directory "+dir);
   			IJ.log("filename "+filename);
   			IJ.log("width  "+width);
   			IJ.log("height "+height);
   			IJ.log("pixelWidth "+pw);
   			IJ.log("pixelHeight "+ph);
   			IJ.log(" ------------------------");
		}

		savename=dir+filename+".bcrf";
		// check if the original directory is still mounted
		od = new File(dir);
		if (!od.exists()) {
			askuser=true;
			message="** original directory no more available !! **";
		}
	//	if os.path.isfile(savename):     # file exists, ask the user
		ff = new File(savename); // to check if the file exists
		if (ff.exists()){    	// file exists, ask the user
      		askuser=true;
      		message="** SPIP file exists !! **";
		}

		if (askuser){
    		writeit=true;
    		SaveDialog sd = new SaveDialog(message, dir,filename,".bcrf");
    		directory = sd.getDirectory();
    		newname = sd.getFileName();
    		if (newname != null){
        		writeit=true;
        		savename=directory+newname;
			} else {
				writeit=false;
			}
        	if (de_bug){
           		IJ.log("=== user selected: ===\n"+directory);
           		IJ.log(newname);
           		IJ.log(savename);
				IJ.log("writeit = "+writeit);
			}
		}


		if (writeit){
			sliceZunit=fi.valueUnit;
			if (fi.valueUnit.equals("") || fi.valueUnit.equals("a.u.")) { // no Z units in this stack
				ImageStack is=image.getImageStack();
				slicelabel=is.getSliceLabel(image.getSlice());
				if (slicelabel.lastIndexOf("Z/") >0) {
					String [] splitlabel=slicelabel.split("Z/");
					sliceZunit=splitlabel[splitlabel.length-1];	// get *slice* Z unit
				} else {
					sliceZunit="a.u."; // no unit info found
					IJ.showMessage("WARNING", "no Z unit found");
				}
				if (de_bug){
					IJ.log("slice="+image.getSlice());
					IJ.log("slice label="+slicelabel);
					IJ.log("slice Z unit="+sliceZunit);
				}
			}

   			header= "fileformat = bcrf\n";
   			header = header + "xpixels = " + Integer.toString(width) +"\n";
   			header = header + "ypixels = " + Integer.toString(height) +"\n";
   			header = header + "xlength = " + Double.toString(width*pw) +"\n";
   			header = header + "ylength = " + Double.toString(height*ph) +"\n";
   			header = header + "xunit = " + fi.unit +"\n";
   			header = header + "yunit = " + fi.unit +"\n";
   			header = header + "zunit = " + "[" + sliceZunit +"]\n";
   			header = header + "# "+ info +"\n";
			
			someBytes = header.getBytes();
			System.arraycopy(someBytes, 0, headerBytes, 0, someBytes.length);

			pix = (float[]) image.getProcessor().getPixels();  // access pixel data
			filewrite(headerBytes,pix, savename);
		}
		if (!Interpreter.isBatchMode()) {
			IJ.showMessage("", "bcrf exporter: END");
		}
	}  // end of processor




	void filewrite(byte[] header, float[] data, String OutputFileName){
		int size = 4*data.length;
		byte [] outstream = new byte [size];
		int tmp;
		FileOutputStream fos = null;
		try {
      		try {
				fos = new FileOutputStream(OutputFileName);
				for (byte b:header) {
					fos.write(b);
				}
				int index=0;
				for (float f:data) {
					tmp = Float.floatToRawIntBits(f);
					outstream[index]   = (byte)tmp;
                    outstream[index+1] = (byte)(tmp>>8);
                    outstream[index+2] = (byte)(tmp>>16);
                    outstream[index+3] = (byte)(tmp>>24);
                    index=index+4;
				}
				fos.write(outstream);
        		fos.flush();
      		}
      		finally {
				// releases all system resources from the streams
         		if(fos!=null)
            		fos.close();
      		}
    	}
    	catch(FileNotFoundException ex){
    	}
    	catch(IOException ex){
    	}
	}
}


