/* Copyright 2022-2023 Lorenzo Lunelli

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License. */


// export an AFM surface as Spider volume data (Chimera) 
//  ----- Jython versions ------------------------
// v 0.0.1 4-6-2013
// v 0.0.2 5-6-2013 - resample the images if the resolution is not enough or pixels are not square
// v 0.0.3 8-6-2013 - add the choice to export the whole volume or only the surface
// v 0.0.4 9-6-2013 - added progress bar and Spider file size estimation
// v 0.0.5 6-6-2015 - compatible with ImageJ 2
//  -----  Java versions -------------------------
//  v0.1 - first java conversion
//  v0.1.1 - corrected a bug in the computation of the number of slices
//  v0.1.2 20-10-2015 - debug state now is read from command line; corrected a bug in the file extension of unnamed images
//  v0.1.2a 27-11-2018 - debug state read from ImageJ option
//  v0.1.3  04-07-2021 - added an end message when not called in BatchMode


import ij.IJ;
import ij.ImagePlus;
import ij.io.SaveDialog;
import ij.gui.GenericDialog;
import ij.io.FileInfo;
import ij.process.FloatStatistics;
import ij.plugin.filter.PlugInFilter;
import ij.process.ImageProcessor;
import ij.macro.Interpreter;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.DataOutputStream;



public class _3DSpiderExport implements PlugInFilter {
	protected ImagePlus image;

	private boolean de_bug,askuser,writeit;
	private static String envresult = null;   // to read the debug state from command line -Dafmdebug=YES
	private int width,height,nslices;
	private double pw,ph,vox;
	private String info,dir,directory,filename,savename,newname,message,noext;
	private String [] gdmenu = {"Surface","Volume"};
	private String whatexp,messagetouser;
	private float[] pix;
	private double value,minvoxel,delta,filesize,z1,z2;
	private float lenbyt,labrec,labbyt,irec; 		// SPIDER stuff
	private File ff;
	private static FileOutputStream fos = null;
    private static DataOutputStream dos = null;


	public int setup(String arg, ImagePlus image) {
		this.image = image;
		return NO_CHANGES | DOES_32 | NO_UNDO;
	}

	public void run(ImageProcessor ip) {
		de_bug=false;
		// ============  debug ===============
		de_bug = IJ.debugMode;		
		// ============  debug ===============
		minvoxel=0.2;
		GenericDialog gd = new GenericDialog("Options");
		gd.addNumericField("resolution (Ang.) better than:", 2, 0);  // show 0 decimals
		gd.addChoice("Export:",gdmenu,"Surface");
		gd.showDialog();
		if (!(gd.wasCanceled())){
  			value = gd.getNextNumber();
  			if (value>0){
      			minvoxel=value/10.0;   // from Angstrom to nm
  			}
			whatexp=gd.getNextChoice();
			ImageProcessor myip = image.getProcessor();
			FloatStatistics stats = new FloatStatistics(myip);
			delta=stats.max-stats.min;
			if (de_bug){
    			IJ.log("you selected "+whatexp);
				IJ.log("minvoxel="+Double.toString(minvoxel));
				IJ.log("some statistics: "+stats.min+" "+stats.max);
    			//IJ.log(stats);
			}
			askuser=true;	   // by default ask the user for the filename
			message="Select a file name";
 			writeit=true;      // we want to write the output file
			FileInfo  ofi=image.getOriginalFileInfo();
			if (ofi!=null) {
				dir= ofi.directory;    		// case A - standard FileInfo structure
				filename = ofi.fileName;
				askuser=false;
				if (dir==""){           	// case B - trying to recover a misformed FileInfo structure
					noext=filename.substring(filename.lastIndexOf(".")+1);
					dir=noext.substring(1,noext.lastIndexOf("/"));
    				filename=noext.substring(noext.lastIndexOf("/")+1);
				}
			} else {						// case C - no way - we need to ask the user
				dir="";
    			askuser=true;
    			message="Select a file name";
			}
			FileInfo fi=image.getFileInfo();  // java version
			width=fi.width;
			height=fi.height;
			pw = fi.pixelWidth;		// we assume nm here!
			ph = fi.pixelHeight;	// we assume nm here!
			vox=pw;    // in spider voxels are cubic, if this is not the case we need to create a new image with the right parameters
			if (de_bug){
    			IJ.log("width ="+width);
				IJ.log("height="+height);
				IJ.log("pixel width/height: "+pw+"/"+ph);
    			//IJ.log(stats);
			}
	
			if (pw!=ph){
     			if (pw<ph){
					height = (int) (Math.ceil(height*ph/pw));  //data are in nm, results are in voxel units
        			vox=pw;
     			} else {
        			width = (int) (Math.ceil(width*pw/ph)); //data are in nm, results are in voxel units
					vox=ph;
				}
				ij.IJ.showMessage("WARNING","original pixels are not square!");
				if (de_bug){
					IJ.log("--- pixel rato correction ----");
    				IJ.log("width ="+width);
					IJ.log("height="+height);
					IJ.log("pixel width/height: "+pw+"/"+ph);
    				//IJ.log(stats);
				}
			}

			if ((pw>minvoxel) || (ph>minvoxel)){  // we need to increase the image resolution
      			width = (int) (Math.ceil(width*pw/minvoxel));   //data are in nm, results are in voxel units
      			height= (int) (Math.ceil(height*ph/minvoxel)); //data in nm, results are in voxel units
      			vox=minvoxel;
      			ij.IJ.showMessage("WARNING","original resolution lower than " + Double.toString(minvoxel)+ " nm");
			}

			ImageProcessor dupip= myip.resize(width,height);
  			ImagePlus dup = new ImagePlus("DUPLICATE",dupip);
			if (de_bug){
     			dup.show();
			}
			nslices = (int) (Math.ceil(delta/vox))+1; // number of slices
  			filesize = Math.round(width*height*nslices*4/1024/1024*10)/10;  // in MBytes
  			if (vox!=0.1){
     			messagetouser="Voxel size= "+Double.toString(vox*10)+" Ang\n ";
     			messagetouser=messagetouser+"\nActivate the Chimera Coordinates menu\n(under Volume Viewer Panel) to rescale the model\n ";
     			messagetouser=messagetouser+"\nnumber of slices="+Double.toString(nslices)+"\nestimated file size="+Double.toString(filesize)+" MB";
  			} else {
     			messagetouser="Voxel size= "+Double.toString(vox*10)+" Ang\n nnumber of slices="+Double.toString(nslices)+"\nestimated file size="+Double.toString(filesize)+" MB";
			}
  			ij.IJ.showMessage(messagetouser);
			pix = (float[]) dup.getProcessor().getPixels();  // access pixel data
  			dup.close();

			// SPIDER stuff --------------------
  			lenbyt=(float) width * 4; // Record length in bytes
  			labrec = (float) Math.ceil(1024 / lenbyt);  // Number of records in file header
  			labbyt = labrec * lenbyt; // basically, the image data offset
  			irec= (float) nslices * height;    //Total number of records (including header records) in each image 
  			// ----------------------------------
  			if (de_bug){
     			IJ.log("------- image info -------");
     			//IJ.log(ofi);
     			//IJ.log(fi);
     			IJ.log("unit "+fi.unit);
     			IJ.log("info "+fi.info);
     			IJ.log("directory "+dir);
     			IJ.log("filename "+filename);
     			IJ.log("width  "+width);
     			IJ.log("height "+height);
     			IJ.log("pixelWidth "+pw);
     			IJ.log("pixelHeight "+ph);
     			IJ.log(" ------------------------");
			}
			savename=dir+filename+".spi";
			ff = new File(savename);
			if (ff.exists()){    // file exists, ask the user
      			askuser=true;
      			message="** SPIDER file exists !! **";
			}
			if (askuser){
    			writeit=false;
    			SaveDialog sd = new SaveDialog(message, dir,filename);
    			directory = sd.getDirectory();
    			newname = sd.getFileName()+".spi";
    			if (newname != null){
        			writeit=true;
        			savename=directory+newname;
				}
        		if (de_bug){
           			IJ.log("=== user selected: ===\n"+directory);
           			IJ.log(newname);
           			IJ.log(savename);
				}
			}
			if (de_bug){
				IJ.log("=== DEBUG INFO ===\n=== SPIDER STUFF ===");
				IJ.log("delta="+delta);
				IJ.log("vox="+vox);
				IJ.log("nslices="+nslices);
				IJ.log("height="+height);
				IJ.log("width="+width);
				IJ.log("labrec="+labrec);
				IJ.log("labbyt="+labbyt);
				IJ.log("lenbyt="+lenbyt);
			}

			if (writeit){
				fileopen(savename);
     			filewrite((float) nslices);  // 1
    			filewrite((float) height);   // 2
    			filewrite(irec);     	// 3
    			filewrite(0f);   		// 4 not used 
    			filewrite(3f);   		// 5 3D volume
    			filewrite(0f);   		// 6 not used 
    			filewrite(0f);   		// 7 max value (not computed)
    			filewrite(0f);   		// 8 min value (not computed)
    			filewrite(0f);   		// 9 average value (not computed)    
    			filewrite(-1f);  		// 10 St dev  value (not computed)
    			filewrite(0f);   		// 11 not used   
    			filewrite((float) width); 	// 12
    			filewrite(labrec); 	// 13
    			filewrite(0f);   		// 14 angles not presents
    			for (int i=0; i<6;i++){
					filewrite(0f);  //  parameters 15-20
				}
    			filewrite(1f); 		// 21 scale factor (it seems that Chimera does not make any use of it)
    			filewrite(labbyt); 	// 22 Total number of bytes in header
    			filewrite(lenbyt); 	// 23 Record length in bytes
    			filewrite(0f);   		// 24 ISSTACK flag
				for (int i=0; i<13;i++){
					filewrite(0f);  //  parameters 25-37
				}
    			filewrite((float) vox*10); 	// 37 voxel size in angstrom (it seems that Chimera does not make any use of it)
    			for (int i=0;i<((int)lenbyt-37);i++){
         			filewrite(0f);
				}
    			for (int slice=0;slice<nslices;slice++){
      				z1=stats.min+vox*slice;
      				z2=z1+vox;
      				ij.IJ.showProgress(slice,nslices);
      				for (int row=0;row<height;row++){
          				for (int col=0;col<width;col++){
	      					value=pix[col+width*row];
	      					if (whatexp=="Surface"){
	          					if ((value>=z1) && (value<z2)) {
	              					filewrite(100f);
								} else {
	              					filewrite(0f);
								}
							}
	      					if (whatexp=="Volume"){
	          					if (value<z2){
	              					filewrite(0f);
								} else {
	              					filewrite(1f);
								}
							}
          				}
      				}
    			}
    			fileclose();
			}
		}
		if (!Interpreter.isBatchMode()) {
			IJ.showMessage("", "Spider exporter: END");
		}
	}	// end of processor




	void fileopen(String OutputFileName){
		fos = null;
      	dos = null;
		try {
      		try {
				fos = new FileOutputStream(OutputFileName);
				dos = new DataOutputStream(fos);
      		}
      		finally {
      		}
    	}
    	catch(FileNotFoundException ex){
    	}
	}




	void filewrite(float number){
		try {
      		try {				
					//dos.writeFloat(number);
					dos.writeInt(Integer.reverseBytes(Float.floatToIntBits(number))); // from little to BIG endianness (bcrf format requirement)
      		}
			finally {
      		}
    	}
    	catch(FileNotFoundException ex){
    	}
    	catch(IOException ex){
    	}
	}


	void fileclose(){
		try {
      		try { 
        		dos.flush();
      		}
      		finally {
				// releases all system resources from the streams
         		if(fos!=null)
            		fos.close();
      		}
    	}
    	catch(FileNotFoundException ex){
    	}
    	catch(IOException ex){
    	}
	}


}
