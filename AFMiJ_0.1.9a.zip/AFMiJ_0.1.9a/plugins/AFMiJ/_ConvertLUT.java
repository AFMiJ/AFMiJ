/* Copyright 2022 Lorenzo Lunelli

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License. */



// this script converts gwyddion color gradients to ImageJ LUTs
// r,g,b are the input values, rlut,glut,blut the output arrays
// v0.1 21-5-2013 - initial version, creates a text file that needs user intervention to be utilized in ImageJ
// v0.2  7-6-2013 - now creates a 768 byte binary LUT file in the standard ImageJ LUT directory
//  -----  Java versions -------------------------
//  v 0.3 	25-8-2015 started java conversion
//  v 0.3a	02-9-2015 
//  v 0.4 - 20-10-2015 debug state now is read from command line
//  v 0.4a - 27-11-2018 - debug state read from ImageJ options
//  v 0.4b - 02-01-2020 - improved GUI
//  v 0.4c	 30-08-2023 - removed a bug when canceling the file chooser dialog, removed a bug when saving a converted LUT (path updated)


import java.io.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.*;
//
import ij.IJ;
import ij.ImagePlus;
import ij.io.OpenDialog;
import ij.gui.GenericDialog;
import ij.gui.HTMLDialog;
import ij.plugin.PlugIn;
import ij.process.ImageProcessor;
import ij.process.LUT;
import ij.WindowManager;

public class _ConvertLUT  extends ImagePlus implements PlugIn {

	static FileInputStream fis = null;
	static DataInputStream dis = null;
	static boolean de_bug = false;
	//private static String envresult = null;   // to read the debug state from command line -Dafmdebug=YES

	public void run(String path) {
		String home=null;
		String gwdir=null;
		boolean usdir,apply,save,osl;
		double oslZ;

		de_bug=false;
		// ============  debug ===============
		de_bug = IJ.debugMode;
		// ============  debug ===============
		
		String sp = System.getProperty("file.separator");
		usdir=false;
		apply=true;
		save=false;
		osl=false;
		GenericDialog gd = new GenericDialog("LUT Conversion Options");
		gd.addCheckbox("user selected input dir?", usdir);
		gd.addCheckbox("apply converted LUT to the current image?", apply);
  		gd.addCheckbox("save converted LUT in ImageJ format?", save);
		gd.showDialog();
		if (!(gd.wasCanceled())){
			usdir=gd.getNextBoolean();
			apply=gd.getNextBoolean();
			save=gd.getNextBoolean();
			if (IJ.isMacOSX() || IJ.isLinux()) {
				dprint("this is NOT windows","");
				home=IJ.getDirectory("home");
				gwdir=home+".gwyddion"+sp+"gradients"; // here we assume that a standard (Linux/OSX) gwyddion installation exists
			}
			else {
				dprint("is this windows?","");
				usdir=true;
			}
			if (usdir == true) {gwdir=null;}
			dprint("HOME=",home);
			dprint("Gwyddion gradient dir=",gwdir);
			OpenDialog od = new OpenDialog("Choose a Gwyddion Gradient file", gwdir,null);
			if (od.getPath() !=null) {
				String filename = od.getFileName();
				String lutdir=IJ.getDirectory("plugins")+"AFMiJ"+sp+"luts";
				String lutpath=lutdir+sp+filename+".converted.lut";
				dprint("exporting to LUT file: ",lutpath);
				if (filename != null){
					// we can continue
					String firstline = null;
					String line = null;
					String [] c = new String[5];
					List<Double> z = new ArrayList<Double>();
					List<Double> r = new ArrayList<Double>();
					List<Double> g = new ArrayList<Double>();
					List<Double> b = new ArrayList<Double>();
					byte [] rbyte = new byte[256];
					byte [] gbyte = new byte[256];
					byte [] bbyte = new byte[256];
					double z1,z2,r1,r2,g1,g2,b1,b2,delta,dz,Z_nm;
					int i,i1,i2;
					int rr = 0;
					int gg = 0;
					int bb = 0;
					int count=0;
					int countarr=0;
					String filepath = od.getPath();
					dprint("reading ",filepath);
					try { // =================== file reading =========================
						FileReader fileReader =  new FileReader(filepath);
						BufferedReader bufferedReader = new BufferedReader(fileReader);
						
						if ((firstline = bufferedReader.readLine()).equals("Gwyddion resource GwyGradient")){
							dprint ("Perfect","we got a Gwyddion lut file!");
						}
						while((line = bufferedReader.readLine()) != null) {
							if (line.startsWith("#")){ // this line is a comment
								dprint("COMMENT line is ",line);
							} else {
								dprint("line is ",line);
								c = line.split(" +|\t+");	// regexp with two possibilities: space or tab, also with repetions
								dprint(c[0],c[1]);
								dprint(c[2],c[3]);
								z.add(Double.parseDouble(c[0]));
								r.add(Double.parseDouble(c[1]));
								g.add(Double.parseDouble(c[2]));
								b.add(Double.parseDouble(c[3]));
								count++;
							}
						}
					}
					catch(FileNotFoundException ex) {
					}
					catch(IOException ex) {
					}
					for (int color =0; color<256;color++){
						Z_nm=color/255.0;
						if (Z_nm<z.get(0)){
							rr=(int) (255.0*r.get(0));
							gg=(int) (255.0*g.get(0));
							bb=(int) (255.0*b.get(0));
						}
						for (i1=0;i1< count-1;i1++){
							i2=i1+1;
							z1=z.get(i1);  // heights
							z2=z.get(i2);
							r1=r.get(i1);  // red
							r2=r.get(i2);
							g1=g.get(i1);  // green
							g2=g.get(i2);
							b1=b.get(i1);  // blue
							b2=b.get(i2);
							if ((Z_nm>=z1)&& (Z_nm<z2)){
								delta = z2-z1;
								dz = Z_nm-z1;
								rr = (int) (255 * (dz * (r2 -r1) / delta + r1));
								gg = (int) (255 * (dz * (g2 -g1) / delta + g1));
								bb = (int) (255 * (dz * (b2 -b1) / delta + b1));
							}
						} // end for input color iterations
						if (Z_nm>z.get(z.size()-1)) {    // colors after the scale maximum
							rr= (int) (255*r.get(z.size()-1));
							gg= (int) (255*g.get(z.size()-1));
							bb= (int) (255*b.get(z.size()-1));
						}
						rbyte[countarr]= (byte) rr;
						gbyte[countarr]= (byte) gg;
						bbyte[countarr]= (byte) bb;
						countarr++;
					} // end for output color iterations
					if (apply){ // ============= apply LUT ========================
						if (WindowManager.getCurrentImage()!=null) { // there is an open image
							ImagePlus imp = IJ.getImage();
							ImageProcessor ip = imp.getProcessor();
							LUT ijlut = new LUT(rbyte,gbyte,bbyte);
							ip.setLut(ijlut);
							imp.updateAndDraw();
						}
					}
					if (save){ // =========== save ImageJ LUT =====================
						new HTMLDialog("ImageJ LUT SAVE PATH", "<h4>"+lutpath);
						FileOutputStream fos = null;
						try {
							try {
								fos = new FileOutputStream(lutpath);
								fos.write(rbyte,0,256);
								fos.write(gbyte,0,256);
								fos.write(bbyte,0,256);
								fos.flush();
							}
							finally {
								// releases all system resources from the streams
								if(fos!=null) {
									fos.close();
								}
							}
						}
						catch(FileNotFoundException ex){
							IJ.log("file not found exception while writing LUT table!");
						}
						catch(IOException ex){
							IJ.log("error writing data in LUT table!");
						}
					}
				}
			}
		}
	} // ********************** END RUN ***********************************

	// ========================= FUNCTIONS =============================
	//
	//
	//
	//
	void dprint(String arg1, String arg2){
		if (de_bug){
			IJ.log("*"+arg1+"*    *"+arg2+"*");
		}
	}
}
