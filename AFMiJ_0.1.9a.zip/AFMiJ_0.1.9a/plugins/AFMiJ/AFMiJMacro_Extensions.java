import ij.*;
import ij.macro.*;
import ij.plugin.*;
import ij.measure.Calibration;


public class AFMiJMacro_Extensions implements PlugIn, MacroExtension {


  public void run(String arg) {
    if (!IJ.macroRunning()) {
      IJ.error("Cannot install extensions from outside a macro!");
      return;
    }
    Functions.registerExtensions(this);
  }
  
  private ExtensionDescriptor[] extensions = {
      ExtensionDescriptor.newDescriptor("isDebugMode",this),
      ExtensionDescriptor.newDescriptor("anActiveImage", this),
      ExtensionDescriptor.newDescriptor("getZUnits", this),
  };

  public ExtensionDescriptor[] getExtensionFunctions() {
    return extensions;
  }

  public String handleExtension(String name, Object[] args) {
	String result=null;
    if (name.equals("isDebugMode")) {
		boolean bresult=IJ.debugMode;
		result=String.valueOf(bresult);
    } else if (name.equals("anActiveImage")) {
		result="false";
      	ImagePlus imp = IJ.getImage(); // note: if there are no images, no result is returned and the calling macro is stopped
	  	int ID=imp.getID();
		if (ID<0) {
			result="true";
		}
    } else if (name.equals("getZUnits")) {
      	ImagePlus imp = IJ.getImage();
	  	Calibration calib=imp.getCalibration();
	  	result=calib.getValueUnit();
    }
    return result;
  }
}

