/* Copyright 2022 Lorenzo Lunelli

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License. */



//----------------------------------------------------------------------
// ----------------- Gwyddion Simple Format reader --------------------------------------
// v 0.1.0 17-10-2018 - first version
// v 0.1.1 31-12-2018 - implemented as reader plugin
// v 0.1.2 01-09-2020 addedd Getversion method
// v 0.1.3 02-09-2020 changed return codes to int
// v 0.1.4 24-06-2021 set the "AFMiJ" property, and Z units as Label
// v 0.1.4a 20-03-2022 changed initial value of done to -1
// Lorenzo Lunelli
// passed parameters: file path, LUT dir, LUT name, lbl
//
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.lang.Math;

import ij.IJ;
import ij.ImagePlus;
import ij.ImageStack;
import ij.io.OpenDialog;
import ij.io.FileInfo;
import ij.io.FileOpener;
import ij.io.Opener;
import ij.plugin.PlugIn;
import ij.process.ImageProcessor;
import ij.process.LUT;
import ij.Macro;
import ij.measure.Calibration;


public class AFMREADERgsf {

	static FileInputStream fis = null;
	// ============  debug ===============
	static boolean de_bug = IJ.debugMode;
	// ============  debug ===============

	public static String Getversion() {
		String version="0.1.4a";
		return version;
	}

	public static int AFMiJread(String path,String lutdir,String lut,String lbl) {
		String known_formats,directory;
		String requires_version = "1.49v";
		String format=null;
		String sdatablock=null;
		int done = -1;
		
		boolean failure = IJ.versionLessThan(requires_version);
		if (failure) {
			return done;
		}
		
		
		// ============  debug ===============
		de_bug = IJ.debugMode;
		// ============  debug ===============
		String format_id="Gwyddion Simple Field 1.0";
		dprint("**** Hello **** ", " This is the " + format_id +" plugin.");
		known_formats=format_id;

		if (de_bug){
			IJ.log("*"+path+"*\n");
			IJ.log("*"+lutdir+"*\n");
			IJ.log("*"+lut+"*\n");
			IJ.log("*"+lbl+"*\n");
		}

		if (path.equals("")) {
			try {
				OpenDialog od = new OpenDialog("Choose a "+ known_formats+ " file", null);
				directory = od.getDirectory();
				path=directory + od.getFileName();
			} catch(Exception e) {done=-1;return done;};
		}
		if (lut.equals("")) {lut="None";};

		byte[] hdatablock =  fileread(path,1024);
		if (hdatablock==null){
			return done;
		}
		try {
			sdatablock = new String(hdatablock, "US-ASCII");
		} catch (UnsupportedEncodingException e) {
		}
		dprint("^^^ trying to find the right format ... ^^^",known_formats);
		dprint("read string length is:",Integer.toString(sdatablock.length()));
		dprint("read string is",sdatablock);
// 		Step 0, identify the file format
		if (sdatablock.startsWith(format_id)){ // **** depends on the file format ****
			format="gwyddion_gsf";
			//------------------------ gsf reader code below -------------------------

			int width=0;
			int height=0;
			int offset=0;
			int headerlength=0;
			float pixelWidth=0;
			float pixelHeight=0;
			float zfactor=1.0f;
			String comment=null;
			String imagename=null;
			String imagepath=null;
			String dum=null;
			String header=null;
			String dimLabel=null;
			String XYUnits=null;
			String ZUnits=null;
			String [] myZUnits={"nm"};
			String label,svalue;

			dprint("----------> in gsf reader method","");
			dprint("(gsf reader) file path=",path);
			byte[] datablock =  fileread(path,0);
			try {
				  dum = new String(datablock, "US-ASCII");
					} catch (UnsupportedEncodingException e) {
				}
				
			// step 1: get image info
			header = dum.split("\\x00")[0];
			headerlength = header.length();
			offset = headerlength + 4 - headerlength % 4;
			dprint("gsf offset=",Integer.toString(offset));
			dprint("gsf header length=",Integer.toString(headerlength));
			dprint("gsf header=",header);
			String [] lines = header.split("\\x0A");
			comment="";
			for (String line:lines) {
				dprint("-----",line);
				label = line.split("=")[0].trim();  // .trim() removes leading and trailing spaces
				if (line.split("=").length == 2) {
					svalue = line.split("=")[1];
					dprint (label,svalue);
					if (label.equals("XRes")) {
						width =  Integer.parseInt(svalue.trim()); 
					} else if (label.equals("YRes")) {
						height =  Integer.parseInt(svalue.trim());
					} else if (label.equals("XReal")){
						pixelWidth = Float.parseFloat(svalue.trim());
					} else if (label.equals("YReal")){
						pixelHeight = Float.parseFloat(svalue.trim());
					} else if (label.equals("Title")){
						dimLabel = svalue.trim();
					} else if (label.equals("XYUnits")){
						XYUnits = svalue.trim();	
					} else if (label.equals("ZUnits")){
						ZUnits = svalue.trim();	
					} else {
						comment = comment + line + " ";
					}
				}
			}

			dprint("comment is:",comment);
			pixelWidth = pixelWidth/width;
			pixelHeight = pixelHeight/height;
			if (XYUnits.equals("m")) {  // convert units to nm
				pixelWidth = pixelWidth*1.e9f;
				pixelHeight = pixelHeight*1.0e9f;
			} else if (XYUnits.equals("mm")) {  // convert units to nm
				pixelWidth = pixelWidth*1.e6f;
				pixelHeight = pixelHeight*1.0e6f;
			}else if (XYUnits.equals("nm")) {  // convert units to nm
				// do nothing
			} else {
				ij.IJ.showMessage("Panic!\nunknown XY units!\nusing nm!");
			}

			if (ZUnits.equals("m")|| ZUnits.equals("nm")) {
				myZUnits[0]="nm";
			} else {
				myZUnits[0]=ZUnits;
			}

			if (ZUnits.equals("m")) {  // convert units to nm
				zfactor=1.0e9f;
				dprint("scaled to nm from... ",ZUnits);
			} else if (ZUnits.equals("nm")) {
				zfactor=1.0f;
				dprint("scaled to nm from... ",ZUnits);
			}

			dprint (Integer.toString(width),Integer.toString(height));
			dprint (Float.toString(pixelWidth), Float.toString(pixelHeight));
				
		// step 2: read the data
		// build the FileInfo structure (contains everything about the image... scale, units, format...)
			String os_sep = System.getProperty("file.separator");
			imagename=path.substring(path.lastIndexOf(os_sep)+1);
			imagepath=path.substring(0,path.lastIndexOf(os_sep));
			dprint("image path=",imagepath);
			dprint("image name=",imagename);
			
			FileInfo fi = new FileInfo();
			
			fi.directory = imagepath;
			fi.fileName = imagename;
			fi.fileType = FileInfo.GRAY32_FLOAT;
			fi.fileFormat = FileInfo.RAW;
			fi.width = width;
			fi.height = height;
			fi.intelByteOrder = true;
			fi.unit ="nm";
			fi.valueUnit =myZUnits[0];
			fi.pixelWidth = pixelWidth;
			fi.pixelHeight = pixelHeight;
			fi.info = comment;
			fi.nImages = 1;
			fi.offset = offset;
			myZUnits[0]="Z/"+myZUnits[0];
			fi.sliceLabels = myZUnits;

			dprint ("Reading the image now...", "");
			FileOpener fo = new FileOpener(fi);
			ImagePlus imp = fo.open(false);
			imp.getProcessor().multiply(zfactor);
			
			if (!lut.equals("None")){ // set the LUT
				LUT ijlut = Opener.openLut(lutdir+lut); 
				imp.getProcessor().setLut(ijlut);
			}
			if (lbl.equals("lbl")){
				AUTOLBL(imp,0);
			}
			imp.setProp("AFMiJ","yes");		// AFM image
			imp.show();
			done = 1;
		}
		else {
			done=-1;
		}
		
		//dprint("format=",format)
	//	if (format==null){
    //		IJ.showMessage("ERROR","file format:\n--- "+fext+" ---\nnot recognized !");
	//	}
		return done;
	} // ********************** END READ ***********************************


	// ========================= FUNCTIONS =============================
	//
	//
	//
	static void AUTOLBL (ImagePlus imp, int slice){
	//   v 0.4.0 12-7-2015 java conversion of jython  # v 0.3.1 24-5-2013 - modified to handle stacks	
		int nlines,npoints,stacksize;
		float mean;
		float [] data=null;
		float[] pix;
		ImageProcessor ip=null;			// define here the image structures 
		ImageStack stack =null;
		
		dprint("in autolbl plugins","");
		dprint ("slice is:",Integer.toString(slice));
		nlines=imp.getHeight();
		dprint ("nlines=",Integer.toString(nlines));
		npoints= imp.getWidth();
		dprint ("npoints=",Integer.toString(npoints));
		stacksize = imp.getImageStackSize();
		dprint("INFO slice is "+slice,", stack size is "+stacksize );
		if (slice>stacksize){
			IJ.log("error slice is "+slice+", stack size is "+stacksize);
			return;
		}
		if (stacksize==1) {   // no stack
			ip = imp.getProcessor();
			dprint("acquiring data from no stack","");
		} else {
			stack = imp.getImageStack();		// stack
			ip = stack.getProcessor(slice);
			dprint("acquiring data from stack size=",Integer.toString(stacksize));
		}
		for (int y=0;y<nlines;y++){
			mean=0;
			data = ip.getRow(0, y, data, npoints);
			for (int x=0;x<data.length;x++){
				mean=mean+data[x];
			}
			mean=mean/npoints;
			for (int x=0;x<data.length;x++){
				data[x]=data[x]-mean;
			}
			ip.putRow(0, y, data, npoints);
		}
	}


	static void dprint(String arg1, String arg2){
		if (de_bug){
			IJ.log("*"+arg1+"*    *"+arg2+"*");
		}
	}



	static byte[] fileread(String InputFileName, int numbytes){   // numbytes=0 means to the end of the file, if numbytes exceeds the file length, the file is read to the end.
		FileInputStream fis = null;
		byte[] buf = null;
		int length;
      	try {
			try {
				fis = new FileInputStream(InputFileName);
				length = Math.min(fis.available(),numbytes);
				if (numbytes==0){
					length=fis.available();
				}
				dprint("bytes to read are: ",Integer.toString(length));
				buf = new byte[length];
				fis.read(buf);
			}
			finally {
				// releases all system resources from the streams
				if(fis!=null) {
            		fis.close();
				}
			}
		}
    	catch(FileNotFoundException ex){
    	}
    	catch(IOException ex){
    	}
		return buf;
	}
}
