/* Copyright 2022 Lorenzo Lunelli

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License. */



//----------------------------------------------------------------------
// ----------------- gwyddion file reader -------------------------------
//  v 0.6.0.4 19-7-2015 - first java conversion from python version: v 0.6.0.3 4-12-2013 - removed a bug (units were not set in non-stacked images)
//  v 0.6.1 2-7-2016  - bug removed from byte array <-> string conversions
//  v 0.7.0 30-10-2018 - improved compatibility, better image grouping in stacks, removed a bug when setting units
//	v 0.8.0 18-01-2019 - implemented as reader plugin
//	v 0.8.1 22-04-2019 - removed a bug when called with no path
//	v 0.8.2 01-09-2020 addedd Getversion method
//  v 0.8.3 02-09-2020 changed return codes to int
//  v 0.9.0 26-06-2021 set the "AFMiJ" property, and Z units as Label
//  v 0.9.0a 20-03-2022 changed initial value of done to -1
// Lorenzo Lunelli

// passed parameters: file path, LUT dir, LUT name, lbl
//
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.lang.Math;

import ij.IJ;
import ij.ImagePlus;
import ij.ImageStack;
import ij.io.OpenDialog;
import ij.io.FileInfo;
import ij.io.FileOpener;
import ij.io.Opener;
import ij.plugin.PlugIn;
import ij.process.ImageProcessor;
import ij.process.LUT;
import ij.Macro;
import ij.measure.Calibration;


public class AFMREADERgwy {

	static FileInputStream fis = null;
	// ============  debug ===============
	static boolean de_bug = IJ.debugMode;
	// ============  debug ===============

	public static String Getversion() {
		String version="0.9.0a";
		return version;
	}

	public static int AFMiJread(String path,String lutdir,String lut,String lbl) {
		String known_formats,directory;
		String requires_version = "1.49v";
		String format=null;
		String sdatablock=null;
		int done = -1;
		
		//String fileimagename=null;
		//String imagepath=null;
		String format_id="gwy";
		dprint("**** Hello **** ", " This is the " + format_id +" plugin.");
		known_formats=format_id;
		if (path.equals("")) {
			try {
				OpenDialog od = new OpenDialog("Choose a "+ known_formats+ " file", null);
				directory = od.getDirectory();
				path=directory + od.getFileName();
			} catch(Exception e) {done=-1;return done;};
		} 
		char cc=(char) 00;
		String pattern=null;
		String anotherpattern=null;
		String evenmorepattern=null;
		String channelstring=null;
		String channel=null;
		String dummy=null;
		String os_sep = System.getProperty("file.separator");
		String fileimagename=path.substring(path.lastIndexOf(os_sep)+1);
		String imagepath=path.substring(0,path.lastIndexOf(os_sep));
		String filestring=null;
		byte[] channelbytes =null;
		
		int dataindex,tempindex,byt,offset,length,delta,titleoffset;
		double xyfactor = 1.0e9;
		double zfactor = 1.0e9;
		int xres0,yres0,xres1,yres1,start,end;
		double xreal0,yreal0,xreal1,yreal1;
		double eps = 1.e-2; // tolerance when comparing image dimensions
		boolean zheight = false;
		boolean phase = false;
		ImagePlus ii;
		Calibration calunits = new Calibration();

		boolean showit=false;
		
		if (de_bug) {
			showit=true;
		}
		
		
		boolean failure = IJ.versionLessThan(requires_version);
		if (failure) {
			return done;
		}
		
		// ============  debug ===============
		de_bug = IJ.debugMode;
		// ============  debug ===============


		if (de_bug){
			IJ.log("*"+path+"*\n");
			IJ.log("*"+lutdir+"*\n");
			IJ.log("*"+lut+"*\n");
			IJ.log("*"+lbl+"*\n");
		}
		if (lut.equals("")) {lut="None";};
		byte[] hdatablock =  fileread(path,256);
		if (hdatablock==null){
			return done;
		}
		try {
			sdatablock = new String(hdatablock, "US-ASCII");
		} catch (UnsupportedEncodingException e) {
		}
		dprint("^^^ trying to find the right format ... ^^^",known_formats);
		dprint("read string length is:",Integer.toString(sdatablock.length()));
		dprint("read string is",sdatablock);
		
// 		Step 0, identify the file format
		if (sdatablock.startsWith("GWYP")){
      		format="gwyddion";
			
			List<Integer> indexchannel = new ArrayList<Integer>();
			List<Integer> dataoffset = new ArrayList<Integer>();
			List<Integer> metaindex = new ArrayList<Integer>();
			List<Integer> xres = new ArrayList<Integer>();			// xres contains number of columns
			List<Integer> yres = new ArrayList<Integer>();			// yres contains number of rows
			List<Integer> group = new ArrayList<Integer>();			// the group number
			List<Double> xreal = new ArrayList<Double>();
			List<Double> yreal = new ArrayList<Double>();
			List<String> unit_xy = new ArrayList<String>();
			List<String> unit_z = new ArrayList<String>();
			List<String> title = new ArrayList<String>();
			List<String> ImageNote = new ArrayList<String>();
			List<String> slicelabel = new ArrayList<String>();
			List<ImagePlus> ImageImp = new ArrayList<ImagePlus>();

			dprint ("start of gwyddion file",path);
			byte[] datablock =  fileread(path,0);
			String [] myZUnits={""};

			
			try {
				filestring = new String(datablock, "US-ASCII");
			} catch (UnsupportedEncodingException e) {
			}

			int datachannel = -1;
			for (int ind=0;ind<20;ind++){
				pattern = "/"+Integer.toString(ind) +"/data"+cc;
				dataindex = filestring.indexOf(pattern);
				dprint(Integer.toString(dataindex),pattern);
				if (dataindex!=-1){
					datachannel++;
					indexchannel.add(ind);  //to be used later in metadata retrieving
					dprint ("--------------------","");
					dprint ("list length is  "+Integer.toString(indexchannel.size()),Integer.toString(indexchannel.get(indexchannel.size()-1)));
					// tempindex=dataindex+22; //  :::::::: should be changed to read the "GwyDataField" frame. Done - 30-10-2018
					pattern = "GwyDataField"+cc;
					tempindex = filestring.indexOf(pattern)+13;
					byt=rawtoint(datablock,tempindex);  // length of channel: 4 bytes integer
					// this is the string that contains the channel data
					dprint("length of channel:",Integer.toString(byt));
					channelstring=filestring.substring(dataindex,dataindex+byt); // this substring contains /x/data channel
					// ---  code introduced with java8 ----
					channelbytes = Arrays.copyOfRange(datablock, dataindex,dataindex+byt);
					// ------------------------------------
					// searching in this channelstring nested info
					// ..... xres .....;
					anotherpattern="xres"+cc+"i";
					offset=channelstring.indexOf(anotherpattern);
					xres.add(rawtoint(channelbytes,offset+6));   // +6 because 4 chars are in xres, + 00 + i (total 6) - (i means integer);
					dprint ("xres is",Integer.toString(xres.get(xres.size()-1)));
					// ..... yres .....;
					anotherpattern="yres"+cc+"i";
					offset=channelstring.indexOf(anotherpattern);
					yres.add(rawtoint(channelbytes,offset+6));   // +6 because 4 chars are in yres, + 00 + i (total 6) - (i means integer);
					dprint ("yres is",Integer.toString(yres.get(yres.size()-1)));
					// ..... unit_xy .....
					anotherpattern="si_unit_xy"+cc+"oGwySIUnit"+cc;
					offset=channelstring.indexOf(anotherpattern);
					length = rawtoint(channelbytes,offset+22);
					dprint ("length of xy unit string is",Integer.toString(length));
					unit_xy.add(channelstring.substring(offset+22+4+9,offset+22+4+length-1));   // :::::::: should be checked, but we assume that units are meters
					// +7 because 5 chars are in xreal, + 00 + d (total 7) - (d means double)
					dprint ("I've found these xy units:",unit_xy.get(datachannel));
					if (unit_xy.get(datachannel).equals("m")){
						xyfactor=1.0e9;
					}	else if (unit_xy.get(datachannel).equals("nm")) {
						xyfactor=1.0;
					}
					// ..... unit_z .....
					anotherpattern="si_unit_z"+cc+"oGwySIUnit"+cc;
					offset=channelstring.indexOf(anotherpattern);
					length = rawtoint(channelbytes,offset+21);
					dprint ("length of z unit string is",Integer.toString(length));
					unit_z.add(channelstring.substring(offset+21+4+9,offset+21+4+length-1));   // :::::::: should be checked, but we assume that units are meters
					// +7 because 5 chars are in xreal, + 00 + d (total 7) - (d means double)
					dprint ("I've found these z units:",unit_z.get(datachannel));
					// ..... xreal .....;
					anotherpattern="xreal"+cc+"d";
					offset=channelstring.indexOf(anotherpattern);
					xreal.add(rawtodouble(channelbytes,offset+7)*xyfactor);
					// +7 because 5 chars are in xreal, + 00 + d (total 7) - (d means double)
					dprint ("xreal is",Double.toString(xreal.get(xreal.size()-1)));
					// ..... yreal .....;
					anotherpattern="yreal"+cc+"d";
					offset=channelstring.indexOf(anotherpattern);
					yreal.add(rawtodouble(channelbytes,offset+7)*xyfactor);
					// +7 because 5 chars are in xreal, + 00 + d (total 7) - (d means double)
					dprint ("yreal is",Double.toString(yreal.get(yreal.size()-1)));
					// ..... data ........
					anotherpattern="data"+cc+"D";
					dataoffset.add(dataindex+channelstring.indexOf(anotherpattern)+6+4);    // the last 4 bytes contain the data length (xres*yres)
					dprint ("data offset", Integer.toString(dataoffset.get(datachannel)));
					// searching the title ....
					evenmorepattern="/"+Integer.toString(ind)+"/data/title"+cc+"s";
					titleoffset=filestring.indexOf(evenmorepattern)+15;  // offset to data channel title
					delta=100;
					if (filestring.length()-titleoffset < delta){
						delta=filestring.length()-titleoffset;
					}
					title.add(filestring.substring(titleoffset,titleoffset+delta).split("\\"+cc)[0]);
					dprint (evenmorepattern, title.get(datachannel));
				}  // end if channel exists
				dprint ("--------------------------------------------------","^^^^^^^^^^^");
			}	// END FOR

			// ------------------ metachannels -----------------------------------------------
			for (int d=0;d<=datachannel;d++){
				ImageNote.add("");
				channel=Integer.toString(indexchannel.get(d));
				pattern="/"+channel+"/meta"+cc;
				metaindex.add(filestring.indexOf(pattern));
				dprint ("metaindex=",Integer.toString(metaindex.get(d)));
				if (metaindex.get(d)!=-1){  // this channel exists
					anotherpattern="ImageNote"+cc+"s";
					offset=filestring.indexOf(anotherpattern);
					if (offset!=-1){
						delta=100;
						if (filestring.length()-offset < delta){
							delta=filestring.length()-offset;
						}
						dummy=filestring.substring(offset,offset+delta).split("\\"+cc)[1];
						if (dummy.startsWith("s")){
							ImageNote.set(d,dummy);
						}
					} // end if 
				} // end if
				dprint(Integer.toString(d),ImageNote.get(d));
			}	// end for

			// =============== GROUPS======================
			// group = 0 -> different geometry channnels
			// group > 0 -> sequence of same geometry channels
			int num_group=0; // number of the group
			boolean newgroup = true;
			xres0=0;
			yres0=0;
			xreal0=0;
			yreal0=0;
			dprint("========== now building the groups... ==============","");
			for (int d=0;d<=datachannel;d++){
				dprint("****** cycle starts *******","");
				xres1=xres.get(d);
				yres1=yres.get(d);
				xreal1=xreal.get(d);
				yreal1=yreal.get(d);
				if (Math.abs(xres1-xres0)<eps && Math.abs(yres1-yres0)<eps && Math.abs(xreal1-xreal0)<eps && Math.abs(yreal1-yreal0)<eps) { // same group 
					if (newgroup) {num_group++;newgroup=false;};
					group.add(num_group);
					group.set(d-1,num_group);
					dprint("group is ",String.valueOf(num_group));
					////////////////////
					dprint("image path=",imagepath);
					dprint("image name=",fileimagename);
				} else { // not in the same group
					group.add(0);
					newgroup=true;
				}
				xres0=xres.get(d);
				yres0=yres.get(d);
				xreal0=xreal.get(d);
				yreal0=yreal.get(d);
				
				if (unit_z.get(d).equals("nm")) {
					zfactor =1;
				} else if (unit_z.get(d).equals("m")) {
					zfactor = 1.0e9;
					unit_z.set(d,"nm");
					dprint("z units scaled to nm... ",ImageNote.get(d));
				} else {
					zfactor =1;
				}
				
				dprint("----------------- d is", String.valueOf(d));
				dprint("just assigned group is ",String.valueOf(group.get(d)));
				
				FileInfo fi = new FileInfo();
				fi.directory = imagepath;
				fi.fileName = fileimagename;
				fi.fileType = FileInfo.GRAY64_FLOAT;
				fi.fileFormat = FileInfo.RAW;
				fi.width = xres.get(d);
				fi.height = yres.get(d);
				fi.intelByteOrder = true;
				fi.unit ="nm";
				fi.valueUnit=unit_z.get(d);
				fi.pixelWidth = xreal.get(d)/(double) xres.get(d);
				fi.pixelHeight = yreal.get(d)/(double) yres.get(d);
				//fi.info = ImageNote.get(d);
				fi.info = title.get(d);
				fi.nImages = 1;
				fi.offset = dataoffset.get(d);
				
				dprint ("Reading the image...", "");
				FileOpener fo = new FileOpener(fi);
				ImagePlus imp = fo.open(showit);
				ImageImp.add(imp);
				//myZUnits[0]="Z/"+unit_z.get(d);
				//fi.sliceLabels = myZUnits;
				slicelabel.add(title.get(d)+" Z/"+unit_z.get(d));
				imp.getProcessor().multiply(zfactor);
				if (title.get(d).startsWith("Height") && lbl.equals("lbl")){
					AUTOLBL(imp,0);
					}
				if (!lut.equals("None")){               // set the LUT
					LUT ijlut = Opener.openLut(lutdir+lut); 
					imp.getProcessor().setLut(ijlut);
				}
				dprint("****** cycle ENDS *******","");
			}		// end for d

			// ******** isolated data ************
			for (int d=0;d<=datachannel;d++){ 
				dprint("-- channel is ",String.valueOf(d));
				dprint("   group is ",String.valueOf(group.get(d)));
				if (group.get(d)==0) {
					ii=ImageImp.get(d);
					//ImageStack is=ii.getStack();
					//is.setSliceLabel("QQWW",1);
					ii.setProperty("Label",slicelabel.get(d));
					ii.setProp("AFMiJ","yes");		// AFM image
					ii.show();
				}
			}

			 // ******* grouped data *************
			for (int g=1;g<=num_group;g++){
				dprint ("assembling group ",String.valueOf(g));
				start = group.indexOf(g);
				end = group.lastIndexOf(g);
				ImageStack stack = ImageImp.get(start).createEmptyStack();
				ImagePlus stackimp = ImageImp.get(start).duplicate();  // duplicate the image (also cal., info etc.)
				int count=1;
				zheight = false;
				phase = false;
				for (int dd=start; dd<=end;dd++) {
					dprint ("adding slice ",String.valueOf(dd));
					ii=ImageImp.get(dd);
					dprint("info is ",ii.getInfoProperty());
					dprint ("slice width ",String.valueOf(ii.getWidth()));
					dprint ("slice height",String.valueOf(ii.getHeight()));
					stack.addSlice(ii.getProcessor());
					stack.setSliceLabel(slicelabel.get(dd),dd-start+1);
					ii.close();
					if (unit_z.get(dd).equals("nm")) {
						zheight = true;
					} else if (unit_z.get(dd).equals("deg")) {
						phase = true;
					}
				}
				stackimp.setStack(fileimagename,stack); //put the stack into the previuously duplicated imageplus
				if (zheight && phase) { // mixed data
					// we need to set the calibration to put the correct units
					calunits.setValueUnit("a.u.");
					calunits.pixelWidth = xreal.get(start)/(double) xres.get(start);
					calunits.pixelHeight = yreal.get(start)/(double) yres.get(start);
					calunits.setXUnit("nm");
					calunits.setYUnit("nm");
					stackimp.setCalibration(calunits);
				}
				stackimp.setProp("AFMiJ","yes");		// AFM image
				stackimp.show();
			} // end for groups
			done = 1;
		}
		else {
			done=-1;
		}
		
		return done;
	} // ********************** END READ ***********************************



	

	// ========================= FUNCTIONS =============================
	//
	//
	//
	static void AUTOLBL (ImagePlus imp, int slice){
	//   v 0.4.0 12-7-2015 java conversion of jython  # v 0.3.1 24-5-2013 - modified to handle stacks	
		int nlines,npoints,stacksize;
		float mean;
		float [] data=null;
		float[] pix;
		ImageProcessor ip=null;			// define here the image structures 
		ImageStack stack =null;
		
		dprint("in autolbl plugins","");
		dprint ("slice is:",Integer.toString(slice));
		nlines=imp.getHeight();
		dprint ("nlines=",Integer.toString(nlines));
		npoints= imp.getWidth();
		dprint ("npoints=",Integer.toString(npoints));
		stacksize = imp.getImageStackSize();
		dprint("INFO slice is "+slice,", stack size is "+stacksize );
		if (slice>stacksize){
			IJ.log("error slice is "+slice+", stack size is "+stacksize);
			return;
		}
		if (stacksize==1) {   // no stack
			ip = imp.getProcessor();
			dprint("acquiring data from no stack","");
		} else {
			stack = imp.getImageStack();		// stack
			ip = stack.getProcessor(slice);
			dprint("acquiring data from stack size=",Integer.toString(stacksize));
		}
		for (int y=0;y<nlines;y++){
			mean=0;
			data = ip.getRow(0, y, data, npoints);
			for (int x=0;x<data.length;x++){
				mean=mean+data[x];
			}
			mean=mean/npoints;
			for (int x=0;x<data.length;x++){
				data[x]=data[x]-mean;
			}
			ip.putRow(0, y, data, npoints);
		}
	}


	static void dprint(String arg1, String arg2){
		if (de_bug){
			IJ.log("*"+arg1+"*    *"+arg2+"*");
		}
	}

	static double rawtodouble(byte[] raw,int offset){	// we need little endianess here
		ByteBuffer buffer = ByteBuffer.wrap(raw,offset,8);
    	return buffer.order(ByteOrder.LITTLE_ENDIAN).getDouble();    //  
	}
	
	static int rawtoint(byte[] raw,int offset){	// we need little endianess here
		ByteBuffer buffer = ByteBuffer.wrap(raw,offset,4);
    	return buffer.order(ByteOrder.LITTLE_ENDIAN).getInt();    //  
	}
	
	

	static byte[] fileread(String InputFileName, int numbytes){   // numbytes=0 means to the end of the file, if numbytes exceeds the file length, the file is read to the end.
		FileInputStream fis = null;
		byte[] buf = null;
		int length;
      	try {
			try {
				fis = new FileInputStream(InputFileName);
				length = Math.min(fis.available(),numbytes);
				if (numbytes==0){
					length=fis.available();
				}
				dprint("bytes to read are: ",Integer.toString(length));
				buf = new byte[length];
				fis.read(buf);
			}
			finally {
				// releases all system resources from the streams
				if(fis!=null) {
            		fis.close();
				}
			}
		}
    	catch(FileNotFoundException ex){
    	}
    	catch(IOException ex){
    	}
		return buf;
	}
}
