/* Copyright 2022 Lorenzo Lunelli

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License. */


//----------------------------------------------------------------------
// ----------------- bcr and bcrf reader -------------------------------

//	v 0.4.0  26-6-2015 java conversion of jython version
//	v 0.4.1	  7-3-2017 removed a bug when reading files without comments
//	v 0.5.0 09-01-2019 implemented as reader plugin
//	v 0.5.1 10-01-2019 merged bcr and bcrf code
//	v 0.5.2 23-07-2019 removed a bug when reading info
//	v 0.5.3 01-09-2020 addedd Getversion method
//  v 0.5.4 02-09-2020 changed return codes to int
//  v 0.6.0 23-06-2021 set the "AFMiJ" property, and Z units as Label
//  v 0.6.0a 20-03-2022 changed initial value of done to -1
// Lorenzo Lunelli
// passed parameters: file path, LUT dir, LUT name, lbl
//
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.lang.Math;

import ij.IJ;
import ij.ImagePlus;
import ij.ImageStack;
import ij.io.OpenDialog;
import ij.io.FileInfo;
import ij.io.FileOpener;
import ij.io.Opener;
import ij.plugin.PlugIn;
import ij.process.ImageProcessor;
import ij.process.LUT;
import ij.Macro;
import ij.measure.Calibration;


public class AFMREADERbcrf {

	static FileInputStream fis = null;
	// ============  debug ===============
	static boolean de_bug = IJ.debugMode;
	// ============  debug ===============

	public static String Getversion() {
		String version="0.6.0a";
		return version;
	}

	public static int AFMiJread(String path,String lutdir,String lut,String lbl) {
		String known_formats,directory;
		String requires_version = "1.49v";
		String format=" ";
		String sdatablock=null;
		int done = -1;
		String bcrf="bcrf";
		String bcrf_unicode="bcrf_unicode";
		String bcr="bcrstm";
		String bcr_unicode="bcrstm_unicode";
		String code=null;
		String maybetheheaderstring=null;
		String header=null;
		String dumheader=null;
		int offset,gotinfo,numline;
		int width=0;
		int height=0;
		float pixelWidth=0;
		float pixelHeight=0;
		double zfactor=1.0;
		float bit2nm=0;
		boolean intelmode=true;
		String comment="";
		String addcomment=null;
		String imagename=null;
		String imagepath=null;
		String xunit="nm"; // in bcr_f files default unit is nm
		String yunit="nm"; // in bcr_f files default unit is nm
		String zunit="nm"; // in bcr_f files default unit is nm
		String xyunit="nm";
		String [] myZUnits={"nm"};
		String line,label,svalue;
		String [] lines = null;
		
		
		boolean failure = IJ.versionLessThan(requires_version);
		if (failure) {
			return done;
		}
		
		
		// ============  debug ===============
		de_bug = IJ.debugMode;
		// ============  debug ===============
		String format_id="bcr and bcrf";
		dprint("**** Hello **** ", " This is the " + format_id +" plugin.");
		known_formats=format_id;

		if (de_bug){
			IJ.log("*"+path+"*\n");
			IJ.log("*"+lutdir+"*\n");
			IJ.log("*"+lut+"*\n");
			IJ.log("*"+lbl+"*\n");
		}

		if (path.equals("")) {
			try {
				OpenDialog od = new OpenDialog("Choose a "+ known_formats+ " file", null);
				directory = od.getDirectory();
				path=directory + od.getFileName();
			} catch(Exception e){done=-1;return done;};
		}
		if (lut.equals("")) {lut="None";};

		byte[] hdatablock =  fileread(path,256);
		if (hdatablock==null){
			return done;
		}
		try {
			sdatablock = new String(hdatablock, "US-ASCII");
		} catch (UnsupportedEncodingException e) {
		}
		dprint("^^^ trying to find the right format ... ^^^",known_formats);
		dprint("read string length is:",Integer.toString(sdatablock.length()));
		dprint("read string is",sdatablock);
		
// 		Step 0, identify the file format
		String [] sdatalines = sdatablock.replace(Character.toString((char) 00), "").split("\\x0A");
		//  -> take the first line (index=0)
		String firstline = sdatalines[0].trim();
		dprint ("first line=", firstline);
		if(firstline.split("=").length>1){
			dprint("number of elements in first line is:",Integer.toString(firstline.split("=").length));
			dprint("[0]=",firstline.split("=")[0]);
			dprint("[1]=",firstline.split("=")[1]);
			code = firstline.split("=")[1].trim();
			// bcrf format -----------------------------------------------------
			if (code.equals(bcrf)) {
				format="bcrf";
			}
			if (code.equals(bcrf_unicode)) {
				format="bcrf_unicode";
			}
			// bcr format -----------------------------------------------------
			if (code.equals(bcr)) {
				format="bcr";
			}
			if (code.equals(bcr_unicode)) {
				format="bcrstm_unicode";
			}			
			
			if (format.startsWith("bcr")) { 
				
				dprint("----------> in bcr_f reader method","");
// step 1: get image info
				dprint("file path=",path);
				byte[] maybetheheader =  fileread(path,4096);   // 4096 is the maximm posssible byte length of the header
				try {
					maybetheheaderstring = new String(maybetheheader, "US-ASCII");
				} catch (UnsupportedEncodingException e) {
				}
				dumheader = maybetheheaderstring.replace(Character.toString((char) 00), "");
				String os_sep = System.getProperty("file.separator");
				if (code.equals(bcrf) || code.equals(bcr) ){
					offset=2048;
					header = maybetheheaderstring.substring(0,2047).replace(Character.toString((char) 00), "");
					lines = header.split("\\x0A");
				}
				else{
					offset=4096;
					lines = dumheader.split("\\x0A");
				}
				dprint ("--lines--","");
				for (int linehead=0; linehead<lines.length;linehead++){
					dprint(String.valueOf(linehead),lines[linehead]);
				}
				gotinfo=0;
				numline=0;
				// phase a, trying to get the image info
				for (numline=0;numline < lines.length;numline++){
					dprint ("-------- numline=",Integer.toString(numline)+" ---------");
					line=lines[numline];
					dprint("line is :",line);
					dprint("line length=",Integer.toString(line.length()));
					if ((line.startsWith("#")) || (line.startsWith("%"))){ // there is a comment here
						addcomment=line.substring(1).trim();
						if (addcomment.length()>0) {
							comment=comment+addcomment+"\n";
							dprint ("got a comment:", line.substring(1));
						}
					}
					else {	// not a comment, try to get some information
						if(line.contains("=")){
							if (line.split("=").length==2) {
								label = line.split("=")[0];
								svalue = line.split("=")[1];
								dprint (label,svalue);
								dprint("gotinfo=",Integer.toString(gotinfo));
								if (label.equals("xpixels ")){
									gotinfo++;
									width =  Integer.parseInt(svalue.trim());
								}
								if (label.equals("ypixels ")){
									gotinfo++;
									height =  Integer.parseInt(svalue.trim());
								}
								if (label.equals("xlength ")){
									gotinfo++;
									pixelWidth = Float.parseFloat(svalue.trim());
								}
								if (label.equals("ylength ")){
									gotinfo++;
									pixelHeight = Float.parseFloat(svalue.trim());
								 }
								if (label.equals("xunit ")){
									gotinfo++;
									xunit = svalue.trim();
								}
								if (label.equals("yunit ")){
									gotinfo++;
									yunit = svalue.trim();
								}
								if (label.equals("zunit ")){
									gotinfo++;
									zunit = svalue.trim();
									if (zunit.length()>3) {
										zunit=zunit.substring(1,zunit.length()-1);
									}
									//IJ.log("zunit="+zunit);
								}
								if (label.equals("bit2nm ")){
									gotinfo++;
									bit2nm = Float.parseFloat(svalue.trim());
								}
								if (label.equals("intelmode ")){
									gotinfo++;
									dprint("found intelmode=",svalue);
									if (svalue.trim().equals("1")) { 
										intelmode = true;
									} else{
										intelmode = false;
									}
								}
							
							}
						}
					}
				}  // end for

				dprint (String.valueOf(gotinfo)," strings read");
				pixelWidth = pixelWidth/width;
				pixelHeight = pixelHeight/height;
				dprint (Integer.toString(width),Integer.toString(height));
				dprint (Float.toString(pixelWidth), Float.toString(pixelHeight));
				dprint (Float.toString(bit2nm),Boolean.toString(intelmode));
				dprint (comment,"");
					
// step 2, read the image data using ImageJ functions
				// build the FileInfo structure (contains everything about the image... scale, units, format...)
				imagename=path.substring(path.lastIndexOf(os_sep)+1);
				imagepath=path.substring(0,path.lastIndexOf(os_sep));
				dprint("image path=",imagepath);
				dprint("image name=",imagename);
				
				if (xunit.equals(yunit)) {
					xyunit=xunit;
				} else {
					xyunit="a.u.";
				}
				
				if (zunit.equals("m")) {  // convert units to nm
					zfactor=1.0e9;
					dprint("scaled to nm from... ",zunit);
					myZUnits[0]="nm";
				} else if (zunit.equals("nm")) {
					zfactor=1.0;
					dprint("scaled to nm from... ",zunit);
					myZUnits[0]="nm";
				} else {
					zfactor=1.0;
					myZUnits[0]=zunit;
				}
				
				FileInfo fi = new FileInfo();
				
				fi.directory = imagepath;
				fi.fileName = imagename;
				if (code.equals(bcrf) || code.equals(bcrf_unicode)) {
					fi.fileType = FileInfo.GRAY32_FLOAT;
				} else if (code.equals(bcr) || code.equals(bcr_unicode)) {
					fi.fileType = FileInfo.GRAY16_SIGNED;
				}
				fi.fileFormat = FileInfo.RAW;
				fi.width = width;
				fi.height = height;
				fi.intelByteOrder = intelmode;
				fi.unit = xyunit;
				fi.valueUnit = myZUnits[0];
				fi.pixelWidth = pixelWidth;
				fi.pixelHeight = pixelHeight;
				fi.info = comment;
				fi.nImages = 1;
				fi.offset = offset;
				myZUnits[0]="Z/"+myZUnits[0];
				fi.sliceLabels = myZUnits;
				
				dprint ("Reading the image now...", "");
				FileOpener fo = new FileOpener(fi);
				ImagePlus imp = fo.open(false);
				
				if (code.equals(bcrf) || code.equals(bcrf_unicode)) {
					imp.getProcessor().multiply(zfactor);
				} else if (code.equals(bcr) || code.equals(bcr_unicode)) {
					ImageProcessor ip = imp.getProcessor().convertToFloatProcessor();    // we want floating point images
					imp.setProcessor(ip);
					imp.getProcessor().multiply(bit2nm);       // apply the bits to nm conversion
					imp.getProcessor().resetMinAndMax();
				}
		
				if (!lut.equals("None")){               // set the LUT
					LUT ijlut = Opener.openLut(lutdir+lut); 
					imp.getProcessor().setLut(ijlut);
				}
				if (lbl.equals("lbl")){
					AUTOLBL(imp,0);
				}
				imp.setProp("AFMiJ","yes");		// AFM image
				imp.show();
				done = 1;
			}
		//-----------------------------------------------------------------------
		}
		else {
			done=-1;
		}
		
		return done;
	} // ********************** END READ ***********************************



	

	// ========================= FUNCTIONS =============================
	//
	//
	//
	static void AUTOLBL (ImagePlus imp, int slice){
	//   v 0.4.0 12-7-2015 java conversion of jython  # v 0.3.1 24-5-2013 - modified to handle stacks	
		int nlines,npoints,stacksize;
		float mean;
		float [] data=null;
		float[] pix;
		ImageProcessor ip=null;			// define here the image structures 
		ImageStack stack =null;
		
		dprint("in autolbl plugins","");
		dprint ("slice is:",Integer.toString(slice));
		nlines=imp.getHeight();
		dprint ("nlines=",Integer.toString(nlines));
		npoints= imp.getWidth();
		dprint ("npoints=",Integer.toString(npoints));
		stacksize = imp.getImageStackSize();
		dprint("INFO slice is "+slice,", stack size is "+stacksize );
		if (slice>stacksize){
			IJ.log("error slice is "+slice+", stack size is "+stacksize);
			return;
		}
		if (stacksize==1) {   // no stack
			ip = imp.getProcessor();
			dprint("acquiring data from no stack","");
		} else {
			stack = imp.getImageStack();		// stack
			ip = stack.getProcessor(slice);
			dprint("acquiring data from stack size=",Integer.toString(stacksize));
		}
		for (int y=0;y<nlines;y++){
			mean=0;
			data = ip.getRow(0, y, data, npoints);
			for (int x=0;x<data.length;x++){
				mean=mean+data[x];
			}
			mean=mean/npoints;
			for (int x=0;x<data.length;x++){
				data[x]=data[x]-mean;
			}
			ip.putRow(0, y, data, npoints);
		}
	}


	static void dprint(String arg1, String arg2){
		if (de_bug){
			IJ.log("*"+arg1+"*    *"+arg2+"*");
		}
	}


	static byte[] fileread(String InputFileName, int numbytes){   // numbytes=0 means to the end of the file, if numbytes exceeds the file length, the file is read to the end.
		FileInputStream fis = null;
		byte[] buf = null;
		int length;
      	try {
			try {
				fis = new FileInputStream(InputFileName);
				length = Math.min(fis.available(),numbytes);
				if (numbytes==0){
					length=fis.available();
				}
				dprint("bytes to read are: ",Integer.toString(length));
				buf = new byte[length];
				fis.read(buf);
			}
			finally {
				// releases all system resources from the streams
				if(fis!=null) {
            		fis.close();
				}
			}
		}
    	catch(FileNotFoundException ex){
    	}
    	catch(IOException ex){
    	}
		return buf;
	}
}
