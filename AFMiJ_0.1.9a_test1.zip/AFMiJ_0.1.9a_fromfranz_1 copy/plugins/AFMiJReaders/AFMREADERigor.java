/* Copyright 2022 Lorenzo Lunelli

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License. */



//----------------------------------------------------------------------
// ----------------- igor wave reader -------------------------------

//	v 0.4.0  July-2015 java implementation from my jython version # v 0.3.5a 26-02-2015 - addedd reading of cypher ES scanner temperature
//	v 0.4.1	 30-10-2015 - added some more info from the AR file
//	v 0.5.0  11-01-2019 - implemented as reader plugin
//  v 0.5.1	 05-06-2019 - improved compatibility with file notes
//  v 0.5.2	 22-07-2019 - improved compatibility with file notes
//  v 0.5.3	 01-09-2020 - improved compatibility with file notes (v 16), addedd Getversion method
//  v 0.5.4  02-09-2020 - changed return codes to int
//  v 0.6.0	 23-06-2021 - set the "AFMiJ" property and Z units as Label
//  v 0.6.1	 20-03-2022 - added check if file contains images, changed initial value of done to -1
// Lorenzo Lunelli
// passed parameters: file path, LUT dir, LUT name, lbl
//
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.lang.Math;

import ij.IJ;
import ij.ImagePlus;
import ij.ImageStack;
import ij.io.OpenDialog;
import ij.io.FileInfo;
import ij.io.FileOpener;
import ij.io.Opener;
import ij.plugin.PlugIn;
import ij.process.ImageProcessor;
import ij.process.LUT;
import ij.Macro;
import ij.measure.Calibration;


public class AFMREADERigor {

	static FileInputStream fis = null;
	// ============  debug ===============
	static boolean de_bug = IJ.debugMode;
	// ============  debug ===============


	public static String Getversion() {
		String version="0.6.1";
		return version;
	}


	public static int AFMiJread(String path,String lutdir,String lut,String lbl) {
		String known_formats,directory;
		String requires_version = "1.49v";
		String format=null;
		String sdatablock=null;
		int done = -1;
		
		int offset,waveoffset,index,idum,width,height,numbytes;
		int numberoffields=0;
		String fileimagename=null;
		String imagepath=null;
		String dumLabels ="";
		String [] dimLabels=null;
		String xyunit="";
		String myZUnits ="";
		double zfactor = 1.0e9;
		double xyfactor = 1.0e9;
		// definitions from Igor Tech Note 003
		int MAXDIMS=4;
		int MAX_WAVE_NAME5=31;
		int MAX_UNIT_CHARS=3;
		boolean isimage=true; // 14-3-2022
		boolean failure = IJ.versionLessThan(requires_version);
		if (failure) {
			return done;
		}
		
		// ============  debug ===============
		de_bug = IJ.debugMode;
		// ============  debug ===============
		String format_id="igor v5";
		dprint("**** Hello **** ", " This is the " + format_id +" plugin.");
		known_formats=format_id;

		if (de_bug){
			IJ.log("*"+path+"*\n");
			IJ.log("*"+lutdir+"*\n");
			IJ.log("*"+lut+"*\n");
			IJ.log("*"+lbl+"*\n");
		}

		if (path.equals("")) {
			try {
				OpenDialog od = new OpenDialog("Choose a "+ known_formats+ " file", null);
				directory = od.getDirectory();
				path=directory + od.getFileName();
			} catch(Exception e){done=-1;return done;};
		}

		if (lut.equals("")) {lut="None";};

		byte[] hdatablock =  fileread(path,256);
		if (hdatablock==null){
			return done;
		}
		try {
			sdatablock = new String(hdatablock, "US-ASCII");
		} catch (UnsupportedEncodingException e) {
		}
		dprint("^^^ trying to find the right format ... ^^^",known_formats);
		dprint("read string length is:",Integer.toString(sdatablock.length()));
		dprint("read string is",sdatablock);
		
// 		Step 0, identify the file format
		
		//---------------- Igor v5, little endian only  --------	
		String igor = new String(new char [] {0x05,0x00});
		if (sdatablock.startsWith(igor)){
			format="igor5";

	 		dprint("----------> in igor v5 reader method","");
			byte[] datablock =  fileread(path,0);		
			
			//# ******* BinHeader structure  *********
			//# **************************************
			offset=0;
			dprint ("--- BinHeader ---","");

			short version = rawtoshort(datablock,offset);
			offset=offset+2;
			dprint ("version=", Short.toString(version));

			short checksum = rawtoshort(datablock,offset);
			offset=offset+2;
			dprint ("checksum=", Short.toString(checksum));

			int wfmSize = rawtoint(datablock,offset);
			offset=offset+4;
			dprint ("wfmSize=", Integer.toString(wfmSize));

			int formulaSize = rawtoint(datablock,offset);
			offset=offset+4;
			dprint ("formulaSize=", Integer.toString(formulaSize));

			int noteSize = rawtoint(datablock,offset);
			offset=offset+4;
			dprint ("noteSize=", Integer.toString(noteSize));

			int dataEUnitsSize = rawtoint(datablock,offset);
			offset=offset+4;
			dprint ("dataEUnitsSize=", Integer.toString(dataEUnitsSize));

			int dimEUnitsSize[] = new int[MAXDIMS];
			index=0;
			for (int i:dimEUnitsSize){
				dimEUnitsSize[index] = rawtoint(datablock,offset+4*(index));
				dprint("dimEUnitsSize=["+Integer.toString(index)+"]=",Integer.toString(dimEUnitsSize[index]));
				index++;
			}
			offset=offset+4*MAXDIMS;

			int dimLabelsSize[] = new int[4];
			index=0;
			for (int i:dimLabelsSize){
				dimLabelsSize[index] = rawtoint(datablock,offset+4*(index));
				dprint("dimLabelsSize=["+Integer.toString(index)+"]=",Integer.toString(dimLabelsSize[index]));
				index++;
			}
			offset=offset+4*MAXDIMS;

			int sIndicesSize = rawtoint(datablock,offset);
			offset=offset+4;
			dprint ("sIndicesSize=", Integer.toString(sIndicesSize));

			int optionsSize1 = rawtoint(datablock,offset);
			offset=offset+4;
			dprint ("optionsSize1=", Integer.toString(optionsSize1));

			int optionsSize2 = rawtoint(datablock,offset);
			offset=offset+4;
			dprint ("optionsSize2=", Integer.toString(optionsSize2));

			dprint ("Binheader length=", Integer.toString(offset));  // Note: should be added some code to check if this length differs from 64 


			//# ******* WaveHeader structure *******
			//# ************************************ 
			dprint("","");
			dprint ("--- WaveHeader ---","");
			
			int WaveHeader5 = rawtoint(datablock,offset);
			offset=offset+4;
			dprint ("WaveHeader5=", Integer.toString(WaveHeader5));

			idum = rawtoint(datablock,offset);		// an unsigned integer represented in a long variable type
			long creationDate = idum & 0xffffffffl;	// an unsigned integer represented in a long variable type
			offset=offset+4;
			dprint ("creationDate=", Long.toString(creationDate));

			idum = rawtoint(datablock,offset);		// an unsigned integer represented in a long variable type
			long modDate = idum & 0xffffffffl;		// an unsigned integer represented in a long variable type
			offset=offset+4;
			dprint ("modDate=", Long.toString(modDate));

			int npnts = rawtoint(datablock,offset);
			offset=offset+4;
			dprint ("npnts=", Integer.toString(npnts));

			short type = rawtoshort(datablock,offset);
			offset=offset+2;
			dprint ("type=", Short.toString(type));

			short dLock = rawtoshort(datablock,offset);
			offset=offset+2;
			dprint ("dLock=", Short.toString(dLock));

			byte whpad1 [] =new byte[6];
			whpad1=Arrays.copyOfRange(datablock, offset, offset+6);
			offset=offset+6;
			dprint("whpad1=",Arrays.toString(whpad1));

			short whVersion = rawtoshort(datablock,offset);
			offset=offset+2;
			dprint ("whVersion=", Short.toString(whVersion));

			byte bname [] =new byte[MAX_WAVE_NAME5+1];
			bname=Arrays.copyOfRange(datablock, offset, offset+MAX_WAVE_NAME5+1);
			offset=offset+MAX_WAVE_NAME5+1;
			dprint("bname=",Arrays.toString(bname));
			String imagename = new String(bname);
			dprint("imagename=",imagename);

			int whpad2 = rawtoint(datablock,offset);
			offset=offset+4;
			dprint ("whpad2=", Integer.toString(whpad2));

			int DataFolder = rawtoint(datablock,offset);
			offset=offset+4;
			dprint ("DataFolder=", Integer.toString(DataFolder));

			int nDim [] =new int[MAXDIMS];
			index=0;
			for (int ii:nDim){
				nDim[index] = rawtoint(datablock,offset+4*(index));
				dprint("nDim=["+Integer.toString(index)+"]=",Integer.toString(nDim[index]));
				index++;
			}
			if (index<3) {isimage=false;} // // added 14-03-2022: images are expected to have at least three nDim[i]>0
			if (index>=3 && nDim[2]==0) {isimage=false;} // added 14-03-2022: images are  expected to have nDim[2]>=1
			dprint("isimage=",Boolean.toString(isimage));
			if (isimage) {
				offset=offset + (4*MAXDIMS);
				double sfA [] =new double[MAXDIMS];
				index=0;
				for (double di:sfA){
					sfA[index] = rawtodouble(datablock,offset+8*(index));
					dprint("sfA=["+Integer.toString(index)+"]=",Double.toString(sfA[index]));
					index++;
				}
				offset=offset + (8*MAXDIMS);

				double sfB [] =new double[MAXDIMS];
				index=0;
				for (double di:sfB){
					sfB[index] = rawtodouble(datablock,offset+8*(index));
					dprint("sfB=["+Integer.toString(index)+"]=",Double.toString(sfB[index]));
					index++;
				}
				offset=offset + (8*MAXDIMS);

				byte dataUnits [] =new byte[MAX_UNIT_CHARS+1];
				dataUnits=Arrays.copyOfRange(datablock, offset, offset+MAX_UNIT_CHARS+1);
				offset=offset+MAX_UNIT_CHARS+1;
				dprint("dataUnits=",Arrays.toString(dataUnits));
				char[] charArr1 = (new String(dataUnits)).toCharArray();
				dprint("dataUnits=",Arrays.toString(charArr1));

				byte dimUnits [] =new byte[MAXDIMS*(MAX_UNIT_CHARS+1)];
				dimUnits=Arrays.copyOfRange(datablock, offset, offset+MAXDIMS*(MAX_UNIT_CHARS+1));
				offset=offset+MAXDIMS*(MAX_UNIT_CHARS+1);
				dprint("dimUnits=",Arrays.toString(dimUnits));
				char[] charArr2 = (new String(dimUnits)).toCharArray();
				dprint("dimUnits=",Arrays.toString(charArr2));
				xyunit=String.valueOf(charArr2[0]);
				dprint("use this xyunit=",xyunit);

				short fsValid = rawtoshort(datablock,offset);
				offset=offset+2;
				dprint ("fsValid=", Short.toString(fsValid));

				short whpad3 = rawtoshort(datablock,offset);
				offset=offset+2;
				dprint ("whpad3=", Short.toString(whpad3));

				double topFullScale = rawtodouble(datablock,offset);
				offset=offset+8;
				dprint ("topFullScale=", Double.toString(topFullScale));

				double botFullScale = rawtodouble(datablock,offset);
				offset=offset+8;
				dprint ("botFullScale=", Double.toString(botFullScale));

				dprint("Computed offset=",Integer.toString(offset+132));  // # Igor private data here (132 bytes), skip them
				offset=offset+132;
				dprint("offset_from_IgorDocs=320+64=",Integer.toString(320+64)); // # add some code to check if these lengths differ
				dprint("Used offset=", Integer.toString(offset));
				
				if (xyunit.equals("m")) {  // convert units to nm
					xyfactor=1.0e9;
					dprint("scaled to nm from... ",xyunit);
				} else if (xyunit.equals("nm")) {
					xyfactor=1.0;
					dprint("scaled to nm from... ",xyunit);
				}


				// Wave data start here 
				if (type==2){  // we want only float ...
					width = nDim[0];
					height= nDim[1];
					numbytes=width*height*4;
					dprint ("numbytes=",Integer.toString(numbytes));
					waveoffset=offset;
					offset=offset+numbytes*nDim[2];  // skip the whole data stream, go to the note

					String note="";
					String initialnote="";
					String lastnote="";
					String imagenote="";        			// ImageNote
					String imagedate="";        			// Date
					String imagetime="";        			// Time
					String scanMode="";						// Scan Mode
					String imagedown="";        			// ScanDown
					String imageangle="";       			// ScanAngle
					String imagerate="";        			// ScanRate
					String imageXoffset="";     			// XOffset
					String imageYoffset="";     			// YOffset
					String imageFreq="";        			// DriveFrequency
					String image2ndFreq="";        			// DriveFrequency1
					String imageSoftver="";     			// Version
					String imageTemp="";        			// ES temperature
					String imageIntegralGain="";			// Integral Gain
					String imageAmplitudeSetpointVolts="";	// Amplitude Set point in Volts
					String imageDriveAmplitude="";			// Drive Amplitude in Volts
					String imageDeflectionSetpointVolts="";	// Deflection Set point in Volts
					String imageMode="";					// ImagingMode
					String imageDualAC="";					// DualACMode

					if (noteSize>0) {		 // if there is a note, read it
						byte [] bytnote= Arrays.copyOfRange(datablock, offset, offset+noteSize);
						String fullnote = new String(bytnote);
						if ((fullnote.indexOf("Initial Parms:")!=-1)) {
							note = fullnote.split("Initial Parms:")[0];
							dprint("note is ...\n",note);
							initialnote = fullnote.split("Initial Parms:")[1];
							dprint("initialnote is ...\n",initialnote);
							if ((fullnote.split("Initial Parms:").length)==3) { // in software version lower than 10 there is no lastnote
								lastnote = fullnote.split("Initial Parms:")[2];
								dprint("lastnote is ...\n",lastnote);
								initialnote = initialnote + lastnote;
							}
						}
						
						String [] notes = note.split("\\x0D");
						for (String nts:notes){
							dprint("in note cycle ",nts);
							if (nts.startsWith("ImagingMode:")) {imageMode=nts.substring(12);}
							if (nts.startsWith("ScanMode:")) {scanMode=nts.substring(9);}
						}
						
						String [] in_notes = initialnote.split("\\x0D");
						for (String nts:in_notes){
							if (nts.startsWith("Initial ScanAngle:")) {imageangle=nts.substring(18);}
							if (nts.startsWith("ScanAngle:")) {imageangle=nts.substring(10);} // for compatibility with versions 9 and 10
							if (nts.startsWith("Initial ScanRate:")) {imagerate=nts.substring(17);}
							if (nts.startsWith("ScanRate:")) {imagerate=nts.substring(9);} // for compatibility with version 9 and 10
							if (nts.startsWith("Initial XOffset:")) {imageXoffset=nts.substring(16);}
							if (nts.startsWith("Initial YOffset:")) {imageYoffset=nts.substring(16);}
							if (nts.startsWith("XOffset:")) {imageXoffset=nts.substring(9);} // for compatibility with version 9 and 10
							if (nts.startsWith("YOffset:")) {imageYoffset=nts.substring(9);} // for compatibility with version 9 and 10
							if (nts.startsWith("DriveFrequency:")) {imageFreq=nts.substring(15);}
							if (nts.startsWith("DriveFrequency1:")) {image2ndFreq=nts.substring(16);}
							if (nts.startsWith("IntegralGain:")) {imageIntegralGain=nts.substring(13);}
							if (nts.startsWith("AmplitudeSetpointVolts:")) {imageAmplitudeSetpointVolts=nts.substring(23);}
							if (nts.startsWith("DriveAmplitude:")) {imageDriveAmplitude=nts.substring(15);}
							if (nts.startsWith("DeflectionSetpointVolts:")) {imageDeflectionSetpointVolts=nts.substring(24);}
							if (nts.startsWith("ScanDown:")) {
								imagedown=nts.substring(10);
								if (imagedown.equals("0")){
									imagedown="Up";
								} else {
									imagedown="Down";
								}
							}
							if (nts.startsWith("ImageNote:")) {imagenote=nts.substring(10);}
							if (nts.startsWith("Date:")) {imagedate=nts.substring(5);}
							if (nts.startsWith("Time:")) {imagetime=nts.substring(5);}
							if (nts.startsWith("DualACMode:")) {
								imageDualAC=nts.substring(12);
								if (imageDualAC.equals("0")){
									imageDualAC="No";
								} else {
									imageDualAC="Yes";
								}
							}
							if (nts.startsWith("Version:")) {imageSoftver=nts.substring(8);}
							if (nts.startsWith("EnvironSampleTemp:")) {imageTemp=nts.substring(18);}
						}
							
						dprint (imagenote,"");
						dprint (imagedate,"");
						dprint (imagetime,"");
						dprint (imagedown,"");
						dprint (imageangle,"");
						dprint (imagerate,"");
						dprint (imageXoffset,"");
						dprint (imageYoffset,"");
						dprint (imageFreq,"");
						dprint (image2ndFreq,"");
						dprint (imageSoftver,"");
						dprint (imageTemp,"");
						dprint (imageIntegralGain,"");
						dprint (imageAmplitudeSetpointVolts,"");
						dprint (imageDriveAmplitude,"");
						dprint (imageDeflectionSetpointVolts,"");
						dprint (imageDualAC,"");
						dprint (imageMode,"");
						dprint (scanMode,"");

					}	// end note
					offset = offset+noteSize;
					for (int dim=0;dim<4;dim++){
						if  (dimLabelsSize[dim]>0){
							numberoffields=dimLabelsSize[dim]/32;   //# 32 from Igor Tech note 003
							dprint("number of fields",Integer.toString(numberoffields));
							dimLabels = new String[numberoffields];
							for (int i=0;i<numberoffields;i++){
								byte [] okpart=Arrays.copyOfRange(datablock, offset+i*32, offset+i*32+32);
								dprint (Integer.toString(i),Arrays.toString(okpart));
								dumLabels = new String(okpart);
								dprint("index=",Integer.toString(dumLabels.indexOf(0)));
								dimLabels[i] = dumLabels.substring(0,dumLabels.indexOf(0));
								dprint(Integer.toString(i),dimLabels[i]);
							}
						}
					}
					
					
					boolean zheight = false;
					boolean phase = false;
					int labindex=0;
					for (String templab:dimLabels) {
						if (templab.startsWith("Height") || templab.startsWith("Amplitude") || templab.startsWith("ZSensor")){
							zheight = true;
							myZUnits="nm";
						} else if (templab.startsWith("Phase")) {
							phase = true;
							myZUnits="deg";
						}
						labindex++;
					}

					if (zheight && phase) { // there are mixed units in the stack
						myZUnits="a.u.";
					}
					
					
					//# image reading code starts here
					//# build the FileInfo structure (contains everything about the images.. scale, units, format..)
					String os_sep = System.getProperty("file.separator");
					fileimagename=path.substring(path.lastIndexOf(os_sep)+1);
					imagepath=path.substring(0,path.lastIndexOf(os_sep));
					dprint("image path=",imagepath);
					dprint("image name=",fileimagename);
					
					FileInfo fi = new FileInfo();
					fi.directory = imagepath;
					fi.fileName = fileimagename;
					fi.fileType = FileInfo.GRAY32_FLOAT;
					fi.fileFormat = FileInfo.RAW;
					fi.width = width;
					fi.height = height;
					fi.intelByteOrder = true;
					fi.unit ="nm";
					fi.valueUnit=myZUnits;
					fi.pixelWidth = sfA[0]*xyfactor;
					fi.pixelHeight = sfA[1]*xyfactor;
					fi.info = "ImageNote="+imagenote+"\n";
					fi.info = fi.info + "Date="+imagedate+"\n";
					fi.info = fi.info + "Time="+imagetime+"\n";
					fi.info = fi.info + "Scan direction="+imagedown+"\n";
					fi.info = fi.info + "Scan angle="+imageangle+"\n";
					fi.info = fi.info + "Scan rate (Hz)="+imagerate+"\n";
					fi.info = fi.info + "Drive Freq. (Hz)="+imageFreq+"\n";
					fi.info = fi.info + "Int. Gain="+imageIntegralGain+"\n";
					fi.info = fi.info + "Drive Amp. (V)="+imageDriveAmplitude+"\n";
					fi.info = fi.info + "Amp. Set Point (V)="+imageAmplitudeSetpointVolts+"\n";
					fi.info = fi.info + "Defl. Set Point (V)="+imageDeflectionSetpointVolts+"\n";
					fi.info = fi.info + "X Offset (m)="+imageXoffset+"\n";
					fi.info = fi.info + "Y Offset (m)="+imageYoffset+"\n";
					fi.info = fi.info + "Temperature="+imageTemp+"\n";
					fi.info = fi.info + "Imaging Mode="+imageMode+"\n";
					fi.info = fi.info + "Dual AC Mode="+imageDualAC+"\n";
					if (imageDualAC.equals("Yes")) {fi.info = fi.info + "Drive 2nd Freq. (Hz)="+image2ndFreq+"\n";}
					fi.info = fi.info + "Scan Mode="+scanMode+"\n";
					fi.info = fi.info + "Software version="+imageSoftver;
					fi.nImages = nDim[2];
					fi.offset = waveoffset;
					dprint ("Reading the images now...", "");
					FileOpener fo = new FileOpener(fi);
					ImagePlus imp = fo.open(false);
					ImageStack stack = imp.getImageStack();
					if (!lut.equals("None")){               // set the LUT
						LUT ijlut = Opener.openLut(lutdir+lut); 
						imp.getProcessor().setLut(ijlut);
					}
					for (index=1;index<=imp.getNSlices();index++){
						ImageProcessor sp = stack.getProcessor(index);
						sp.flipVertical();
						if (numberoffields==(imp.getNSlices()+1)){
							dprint("OK, number of slices and number of labels are the same=",Integer.toString(numberoffields));

							if (dimLabels[index].startsWith("Height") || dimLabels[index].startsWith("Amplitude") || dimLabels[index].startsWith("ZSensor")){
								sp.multiply(zfactor);   //# from units to nm BUG BUG CHECK what happens with single channel images !!!!
								dprint("scaled to nm... ",dimLabels[index]);
								dimLabels[index]=dimLabels[index]+" Z/nm";
							}
							if (dimLabels[index].startsWith("Height") && lbl.equals("lbl")){
								AUTOLBL(imp,index);
							}
							if (dimLabels[index].startsWith("Phase")) {
								dimLabels[index]=dimLabels[index]+" Z/Deg";
							}
							stack.setSliceLabel(dimLabels[index], index);
						}
					}
					IJ.resetMinAndMax(imp);
					imp.setProp("AFMiJ","yes");		// AFM image
					imp.show();
				}  // end waveheader data
				done = 1;
			}
			else {
				done=0;
			}
		}
		else {
			done=-1;
		}
		return done;
	} // ********************** END READ ***********************************



	

	// ========================= FUNCTIONS =============================
	//
	//
	//
	static void AUTOLBL (ImagePlus imp, int slice){
	//   v 0.4.0 12-7-2015 java conversion of jython  # v 0.3.1 24-5-2013 - modified to handle stacks	
		int nlines,npoints,stacksize;
		float mean;
		float [] data=null;
		float[] pix;
		ImageProcessor ip=null;			// define here the image structures 
		ImageStack stack =null;
		
		dprint("in autolbl plugins","");
		dprint ("slice is:",Integer.toString(slice));
		nlines=imp.getHeight();
		dprint ("nlines=",Integer.toString(nlines));
		npoints= imp.getWidth();
		dprint ("npoints=",Integer.toString(npoints));
		stacksize = imp.getImageStackSize();
		dprint("INFO slice is "+slice,", stack size is "+stacksize );
		if (slice>stacksize){
			IJ.log("error slice is "+slice+", stack size is "+stacksize);
			return;
		}
		if (stacksize==1) {   // no stack
			ip = imp.getProcessor();
			dprint("acquiring data from no stack","");
		} else {
			stack = imp.getImageStack();		// stack
			ip = stack.getProcessor(slice);
			dprint("acquiring data from stack size=",Integer.toString(stacksize));
		}
		for (int y=0;y<nlines;y++){
			mean=0;
			data = ip.getRow(0, y, data, npoints);
			for (int x=0;x<data.length;x++){
				mean=mean+data[x];
			}
			mean=mean/npoints;
			for (int x=0;x<data.length;x++){
				data[x]=data[x]-mean;
			}
			ip.putRow(0, y, data, npoints);
		}
	}


	static void dprint(String arg1, String arg2){
		if (de_bug){
			IJ.log("*"+arg1+"*    *"+arg2+"*");
		}
	}

	static double rawtodouble(byte[] raw,int offset){	// we need little endianess here
		ByteBuffer buffer = ByteBuffer.wrap(raw,offset,8);
    	return buffer.order(ByteOrder.LITTLE_ENDIAN).getDouble();    //  
	}
	
	static int rawtoint(byte[] raw,int offset){	// we need little endianess here
		ByteBuffer buffer = ByteBuffer.wrap(raw,offset,4);
    	return buffer.order(ByteOrder.LITTLE_ENDIAN).getInt();    //  
	}
	
	static short rawtoshort(byte[] raw,int offset){	// we need little endianess here
		ByteBuffer buffer = ByteBuffer.wrap(raw,offset,2);
    	return buffer.order(ByteOrder.LITTLE_ENDIAN).getShort();    //  
	}
	
	

	static byte[] fileread(String InputFileName, int numbytes){   // numbytes=0 means to the end of the file, if numbytes exceeds the file length, the file is read to the end.
		FileInputStream fis = null;
		byte[] buf = null;
		int length;
      	try {
			try {
				fis = new FileInputStream(InputFileName);
				length = Math.min(fis.available(),numbytes);
				if (numbytes==0){
					length=fis.available();
				}
				dprint("bytes to read are: ",Integer.toString(length));
				buf = new byte[length];
				fis.read(buf);
			}
			finally {
				// releases all system resources from the streams
				if(fis!=null) {
            		fis.close();
				}
			}
		}
    	catch(FileNotFoundException ex){
    	}
    	catch(IOException ex){
    	}
		return buf;
	}
}
