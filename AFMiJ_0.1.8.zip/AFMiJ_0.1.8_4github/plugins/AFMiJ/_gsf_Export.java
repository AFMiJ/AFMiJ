/* Copyright 2022 Lorenzo Lunelli

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License. */


//
//	v 0.1.0  - 17-10-2017 first version
//	v 0.1.0a - 18-10-2017 now default units for saving are meters
//	v 0.1.1  - 10-10-2020 removed a bug when exporting an image loaded from a device that is then ejected
//	v 0.1.2  - 04-07-2021 - added end message when not called in BatchMode, added better management of Z units

import ij.IJ;
import ij.ImagePlus;
import ij.io.SaveDialog;
import ij.io.FileInfo;
import ij.plugin.filter.PlugInFilter;
import ij.process.ImageProcessor;
import ij.macro.Interpreter;
import ij.ImageStack;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.DataOutputStream;


public class _gsf_Export implements PlugInFilter {
	protected ImagePlus image;

	private boolean de_bug,askuser,writeit;
	private int width,height;
	private double pw,ph;
	private String info,dir,directory,filename,savename,newname,message,noext,header,ZUnits,slicelabel,sliceZunit;
	private byte[] headerBytes,FileBytes;
	private float[] pix;
	private float value;
	private File ff,od;
	private float xyconv;
	private float zconv=1e-9f; // from nm to meters

	public int setup(String arg, ImagePlus image) {
		this.image = image;
		return NO_CHANGES | DOES_32 | NO_UNDO;
	}

	public void run(ImageProcessor ip) {
		
		de_bug=false;
		// ============  debug ===============
		de_bug = IJ.debugMode;
		// ============  debug ===============

		FileInfo  ofi=image.getOriginalFileInfo();
		if (ofi!=null) {
			info = ofi.info;
			dir= ofi.directory;        // case A - standard FileInfo structure
			filename = ofi.fileName;
		}	else {
      		info="";
			dir=null;
			filename=null;
		}

		FileInfo fi=image.getFileInfo();
		width=fi.width;
		height=fi.height;
		pw = fi.pixelWidth;
		ph = fi.pixelHeight;

		askuser=false; // no need to ask the user for filename
		writeit=true;  // we want to write the output file

		if (dir==""){              // case B - trying to recover a misformed FileInfo structure
   			//dum=filename.split(".",1)
			noext=filename.substring(filename.lastIndexOf(".")+1);
    	//	noext=dum[0];
    		//dum=noext.rsplit(os.sep,1)
			dir=noext.substring(1,noext.lastIndexOf("/"));
    		filename=noext.substring(noext.lastIndexOf("/")+1);
		}
		if (dir==null){            // case C - no way - we need to ask the user
    		dir="";
    		askuser=true;
    		message="Select a file name";
		}

		if (de_bug) {
			IJ.log("------- file info -------");
   			IJ.log("XYunits "+fi.unit);
   			IJ.log("Zunit "+fi.valueUnit);
  			IJ.log("info "+info);
  			IJ.log("directory "+dir);
   			IJ.log("filename "+filename);
   			IJ.log("width  "+width);
   			IJ.log("height "+height);
   			IJ.log("pixelWidth "+pw);
   			IJ.log("pixelHeight "+ph);
   			IJ.log(" ------------------------");
		}

		savename=dir+filename+".gsf";
		// check if the original directory is still mounted
		od = new File(dir);
		if (!od.exists()) {
			askuser=true;
			message="** original directory no more available !! **";
		}
		//	if os.path.isfile(savename):     # file exists, ask the user
		ff = new File(savename); // to check if the file exists
		if (ff.exists()){    	// file exists, ask the user
			askuser=true;
			message="** file exists !! **";
		}

		if (askuser){
    		writeit=true;
    		SaveDialog sd = new SaveDialog(message, dir,filename,".gsf");
    		directory = sd.getDirectory();
    		newname = sd.getFileName();
    		if (newname != null){
        		writeit=true;
        		savename=directory+newname;
			} else {
				writeit=false;
			}
        	if (de_bug){
           		IJ.log("=== user selected: ===\n"+directory);
           		IJ.log(newname);
           		IJ.log(savename);
				IJ.log("writeit = "+writeit);
			}
		}

		if (writeit){
			//IJ.log("units "+fi.unit);
			if (fi.unit.equals("nm")){
					xyconv=1e-9f;
				} else if (fi.unit.equals("mm")) {
					xyconv=1e-3f;
				} else if (fi.unit.equals("m")) {
					xyconv=1;
				} else {
					xyconv=1;
					IJ.showMessage("Panic!\nunknown XY units!\nimage saved with meters as units!");
				}
			
			sliceZunit=fi.valueUnit;
			if (fi.valueUnit.equals("") || fi.valueUnit.equals("a.u.")) { // no Z units in this stack
				ImageStack is=image.getImageStack();
				slicelabel=is.getSliceLabel(image.getSlice());
				if (slicelabel.lastIndexOf("Z/") >0) {
					String [] splitlabel=slicelabel.split("Z/");
					sliceZunit=splitlabel[splitlabel.length-1];	// get *slice* Z unit
				} else {
					sliceZunit="a.u."; // no unit info found
					IJ.showMessage("WARNING", "no Z unit found");
				}
				if (de_bug){
					IJ.log("slice="+image.getSlice());
					IJ.log("slice label="+slicelabel);
					IJ.log("slice Z unit="+sliceZunit);
				}
			}

			if (sliceZunit.equals("nm")){
					zconv=1e-9f;
					ZUnits="m";
				} else if (sliceZunit.equals("mm")) {
					zconv=1e-3f;
					ZUnits="m";
				} else if (sliceZunit.equals("m")) {
					zconv=1;
					ZUnits="m";
				} else {
					zconv=1;
					ZUnits=sliceZunit;
				}

   			header= "Gwyddion Simple Field 1.0\n";
   			header = header + "XRes = " + Integer.toString(width) +"\n";
   			header = header + "YRes = " + Integer.toString(height) +"\n";
   			header = header + "XReal = " + Double.toString(width*pw*xyconv) +"\n";
   			header = header + "YReal = " + Double.toString(height*ph*xyconv) +"\n";
   			header = header + "XYUnits = m\n";
   			header = header + "ZUnits = " + ZUnits+"\n"+ info +"\n";
			
			int padding = 4 - header.length() % 4;
			if (de_bug){
           		IJ.log("===gsf exporter. header length= "+header.length());
				IJ.log("===gsf exporter. header padding= "+padding);
			}
			for (int i=0; i<padding; i++) {
				header=header + Character.toString ((char) 0);;
				if (de_bug) IJ.log("i="+i+"  adding 1 byte to header"); 
			}
			headerBytes = header.getBytes();
			pix = (float[]) image.getProcessor().getPixels();  // access pixel data
			filewrite(headerBytes,pix, savename,zconv);
		}
		if (!Interpreter.isBatchMode()) {
			IJ.showMessage("", "gsf exporter: END");
		}
	}  // end of processor




	void filewrite(byte[] header, float[] data, String OutputFileName, float zconv){
		int size = 4*data.length;
		byte [] outstream = new byte [size];
		int tmp;
		FileOutputStream fos = null;
		try {
      		try {
				fos = new FileOutputStream(OutputFileName);
				for (byte b:header) {
					fos.write(b);
				}
				int index=0;
				for (float f:data) {
					tmp = Float.floatToRawIntBits(f*zconv);
					outstream[index]   = (byte)tmp;
                    outstream[index+1] = (byte)(tmp>>8);
                    outstream[index+2] = (byte)(tmp>>16);
                    outstream[index+3] = (byte)(tmp>>24);
                    index=index+4;
				}
				fos.write(outstream);
        		fos.flush();
      		}
      		finally {
				// releases all system resources from the streams
         		if(fos!=null)
            		fos.close();
      		}
    	}
    	catch(FileNotFoundException ex){
    	}
    	catch(IOException ex){
    	}
	}
}


