/* Copyright 2022 Lorenzo Lunelli

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License. */

// v 0.1 17-09-2018 - initial version
// v 0.2 21-4-2021 - removed code to change look and feel back to system default on OSX, added more option for opening and closing action bar windows
// v 0.3 09-03-2022 - removed unused code
import ij.*;
import ij.plugin.*;

public class Control_AB implements PlugIn {
	public void run(String s) {
		Action_Bar AB = new Action_Bar();
		Close_AB CAB = new Close_AB();
		String [] command_string = new String[20];
		String opt = Macro.getOptions();

// 	opt is a string with commands followed by option. Command are "close" or "open" as in the following example "close=windowname,open=path_to_file"
// 	if opt is null the Look and Feel on OSX is reset to the system default // removed 21-4-2021 - not necessary anymore
		if (opt!=null) {
		  //IJ.log("arg=*"+opt.trim()+"*");
			command_string = opt.trim().split(",");
			for (String command : command_string) {
				String action=command.split("=")[0];
				String option=command.split("=")[1];
				//IJ.log("AB control command=*"+action+"*");
				//IJ.log("AB control option=*"+option+"*");
				if (action.equals("close") && option !=null){
					if (WindowManager.getWindow(option) != null) {
					Macro.setOptions(option);
						CAB.run(option);
					}
				}
				if (action.equals("open") && option !=null && !option.equals(" ")){
					//IJ.log("calling ActionBar with the option=*"+action+"*");
					Macro.setOptions(null); // check this
					AB.run(option);
				}
			}
		}
	//	else { /* // opt is null // removed 21-4-2021 - not necessary anymore
	//		 }
	}
}
