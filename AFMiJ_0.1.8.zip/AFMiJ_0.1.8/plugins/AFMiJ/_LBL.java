/* Copyright 2022 Lorenzo Lunelli

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License. */



//  v 0.4.0 11-7-2015 java conversion of jython code  # v 0.3.1 24-5-2013 - modified to handle stacks
//	v 0.4.1 20-10-2015 debug state now is read from command line
//	v 0.4.2 10-09-2018 - added "auto" option to fit the whole image (thresholding not considered)
//	v 0.5.0 10-04-2021 - added first  order line-by-line ftting, changed calling parameters

import java.util.*;
import ij.IJ;
import ij.ImagePlus;
import ij.plugin.filter.PlugInFilter;
import ij.process.ImageProcessor;
import ij.process.ImageStatistics;
import ij.Macro;


public class _LBL implements PlugInFilter {
	protected ImagePlus image;
	private boolean de_bug;
	AFM_Undo Undo = new AFM_Undo();
	
	public int setup(String arg, ImagePlus image) {
		this.image = image;
		return DOES_32;
	}
	
	public void run(ImageProcessor ip) {
		de_bug = IJ.debugMode;
		int nlines,npoints,counts;
		double maxT,minT;
		float [] data=null;
		float mean, slope;
		float xm,zm,x2m,zxm;
		float z,value;
		String rawoptions;
		rawoptions=Macro.getOptions().trim();
		dprint("rawoptions=",rawoptions);
		ImageStatistics stats = new ImageStatistics();
		Undo.run("store");  // store an undo snapshot
		dprint("in lbl plugin","");
		nlines=ip.getHeight();
		dprint ("nlines=",Integer.toString(nlines));
		npoints= ip.getWidth();
		dprint ("npoints=",Integer.toString(npoints));
		maxT=ip.getMaxThreshold();
		minT=ip.getMinThreshold();
		if (rawoptions!=null) {
			if (rawoptions.equals("auto 0") || rawoptions.equals("auto 1")) { // use the whole Z range
				stats = ImageStatistics.getStatistics(ip);
				double minZ = stats.min;
				double maxZ = stats.max;
				dprint("min value=",Double.toString(minZ));
				dprint("max value=",Double.toString(maxZ));
				minT=minZ;
				maxT=maxZ;
			}
		}		
		dprint(Double.toString(minT),Double.toString(maxT));
		if (rawoptions!=null) {
			if (rawoptions.equals("auto 0") || rawoptions.equals("masked 0")) { // 0th order
				for (int y=0;y<nlines;y++){
					mean=0;
					counts=0;
					data = ip.getRow(0, y, data, npoints);
					dprint("l=",Integer.toString(data.length));
					for (int x=0;x<data.length;x++){
						z=data[x];
						if ((z>=minT)&&(z<=maxT)){
							//dprint("",Double.toString(z));
							mean=mean+z;
							counts++;
						}
					}
					if (counts!=0) {
						mean=mean/counts;
						for (int x=0;x<data.length;x++){
							data[x]=data[x]-mean;
						}
						ip.putRow(0, y, data, npoints);
					}
					dprint("points inside threshold are: ", Integer.toString(counts));
				}
			} // ----- end 0th order
			if (rawoptions.equals("auto 1") || rawoptions.equals("masked 1")) { // 1st order
				for (int y=0;y<nlines;y++){
					xm=0;x2m=0;zm=0;zxm=0;
					counts=0;
					slope=0;
					data = ip.getRow(0, y, data, npoints);
					dprint("l=",Integer.toString(data.length));
					for (int x=0;x<data.length;x++){
						z=data[x];
						if ((z>=minT)&&(z<=maxT)){
							//dprint("",Double.toString(z));
							zm=zm+z;
							zxm=zxm+z*x;
							xm=xm+x;
							x2m=x2m+x*x;
							counts++;
						}
					}
					if (counts!=0) {
						zm=zm/counts;
						zxm=zxm/counts;
						xm=xm/counts;
						x2m=x2m/counts;
						if (xm*xm!=x2m) {
							slope=(zxm-zm*xm)/(x2m-xm*xm);
						}
						mean=zm-slope*xm;
						dprint(Double.toString(mean),Double.toString(slope));
						for (int x=0;x<data.length;x++){
							data[x]=data[x]-mean-slope*x;
						}
						ip.putRow(0, y, data, npoints);
					}
					dprint("points inside threshold are: ", Integer.toString(counts));
				}
			} // ----- end 1st order
			image.updateAndRepaintWindow();
		}
	}


	void dprint(String arg1, String arg2){
		if (de_bug){
			IJ.log("*"+arg1+"*    *"+arg2+"*");
		}
	}
}
