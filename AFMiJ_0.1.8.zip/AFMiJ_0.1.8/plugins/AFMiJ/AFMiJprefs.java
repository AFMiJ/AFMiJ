/* Copyright 2023 Lorenzo Lunelli

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License. */

//	v 0.1  02-08-2023
//	v 0.2  06-08-2023 added initialize and clear methods
// implements methods to access static AFMiJ prefs

public class AFMiJprefs {
	private static String [] properties=new String[100];
	private static String [] values=new String[100];
	private static int maxprop=0;
	private static String separator=Character.toString((char) 10);

	public static int clear () {
		maxprop=0;
		return 1;
	}

	public static int initialize(String property, String value) {
		properties[maxprop]=property;
		values[maxprop]=value;
		maxprop++;
		return maxprop;
	}

	public static int set (String property, String value) {
		int back=0;
		int i;
		for (i=0;i<maxprop;i++) {
			if (properties[i].equals(property)) {break;};
		}
		if (i==maxprop) { // or maxprop-1?
			back=-1;
		} else {
			values[i]=value;
			back=i;
		}
		return back;
	}

	public static String get (String property) {
		String back="0";
		int i;
		for (i=0;i<maxprop;i++) {
			if (properties[i].equals(property)) {break;};
		}
		if (i==maxprop) {
			back="-1";
		} else {
			back=values[i];
		}
		return back;
	}

	public static String getallnames () {
		String back="";
		int i;
		for (i=0;i<maxprop;i++) {
			back=back+separator+properties[i];
		}
	return back;
	}

	public static String getallvalues () {
		String back="";
		int i;
		for (i=0;i<maxprop;i++) {
			back=back+separator+values[i];
		}
	return back;
	}
}
