// version 0.2 6-3-2016 requires _AFMReader.java plugin version >=0.6, also compatible with the new _AFMReader.ijm macro plugin
import ij.*;
import ij.process.*;
import ij.gui.*;
import java.awt.*;
import ij.plugin.*;
import ij.plugin.frame.*;

public class CallAFMReader implements PlugIn {

	public void run(String arg) {
		IJ.run(" AFMReader",arg+"\r"+"nolutdir");
	}

}
