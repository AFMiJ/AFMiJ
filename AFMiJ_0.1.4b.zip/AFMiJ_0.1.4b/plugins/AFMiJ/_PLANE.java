/* Copyright 2022 Lorenzo Lunelli

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License. */



//  v 0.4.0 11-7-2015 - java conversion of jython  # v 0.3.1 24-5-2013 - modified to handle stacks
//	v 0.4.1 20-10-2015 - debug state now is read from command line
//	v 0.4.2 10-09-2018 - added "auto" option to fit the whole image (thresholding not considered)
//	v 0.4.3 24-09-2018 - debug state now is read from ImageJ debug status

import java.util.*;
import ij.IJ;
import ij.ImagePlus;
import ij.plugin.filter.PlugInFilter;
import ij.process.ImageProcessor;
import ij.process.ImageStatistics;
import ij.measure.*;
import ij.Macro;

public class _PLANE implements PlugInFilter {
	protected ImagePlus image;
	private boolean de_bug;
	private static String envresult = null;   // to read the debug state from command line -Dafmdebug=YES
	AFM_Undo Undo = new AFM_Undo();
	
	public int setup(String arg, ImagePlus image) {
		this.image = image;
		return DOES_32;
	}
	
	public void run(ImageProcessor ip) {
		de_bug = IJ.debugMode;
		int nlines,npoints,counts;
		double maxT,minT,zmean,planey,plane;
		float [] data=null;
		float mean;
		float z,value;
		String rawoptions;
		rawoptions=Macro.getOptions();
		ImageStatistics stats = new ImageStatistics();
		Undo.run("store");  // store an undo snapshot
		dprint("in plane subtraction plugin","");
		nlines=ip.getHeight();
		dprint ("nlines=",Integer.toString(nlines));
		npoints= ip.getWidth();
		dprint ("npoints=",Integer.toString(npoints));
		maxT=ip.getMaxThreshold();
		minT=ip.getMinThreshold();
		if (rawoptions!=null) {
			if (rawoptions.equals("auto ")) {
				stats = ImageStatistics.getStatistics(ip);
				double minZ = stats.min;
				double maxZ = stats.max;
				dprint("min value=",Double.toString(minZ));
				dprint("max value=",Double.toString(maxZ));
				minT=minZ;
				maxT=maxZ;
			}
		}
		dprint(Double.toString(minT),Double.toString(maxT));

		// compute the average Column
		float [] meanCol=new float[nlines];
		for (int y=0;y<nlines;y++){
			meanCol[y]=0;
			counts=0;
			data = ip.getRow(0, y, data, npoints);
			dprint("l=",Integer.toString(data.length));
			for (int x=0;x<data.length;x++){
				z=data[x];
				if ((z>=minT)&&(z<=maxT)){
					//dprint("",Double.toString(z));
					meanCol[y]=meanCol[y]+z;
					counts++;
				}
			}
			if (counts!=0) {
				meanCol[y]=meanCol[y]/counts;
			}
			dprint("points inside threshold are: ", Integer.toString(counts));
		}

		// compute the average Row
		float [] meanRow=new float[npoints];
		for (int x=0;x<npoints;x++){
			meanRow[x]=0;
			counts=0;
			for (int y=0;y<nlines;y++){
				z=ip.getPixelValue(x, y);
				if ((z>=minT)&&(z<=maxT)){
					//dprint("",Double.toString(z));
					meanRow[x]=meanRow[x]+z;
					counts++;
				}
			}
			if (counts!=0) {
				meanRow[x]=meanRow[x]/counts;
			}
			dprint("points inside threshold are: ", Integer.toString(counts));
		}

		// now let compute A and B
		// ----------- A  ------------
		double xmean=0;
		zmean=0;
		double A=0;
		double A2=0;
		counts=0;
		for (int x=0;x<npoints;x++) {
			value=meanRow[x];
			if ((value>=minT)&&(value<=maxT)) {
				xmean=xmean+x;
				zmean=zmean+value;
				counts++;
			}
		}
		if (counts>0) {
			xmean=xmean/counts;
			zmean=zmean/counts;
			for (int x=0;x<npoints;x++) {
				value=meanRow[x];
				if ((value>=minT)&&(value<=maxT)) {
					A=A+(x-xmean)*(value-zmean);
					A2=A2+((x-xmean)*(x-xmean));
				}
			}
			if (A2 !=0) {
				A=A/A2;
			}
		}
		dprint("counts, A -- "+counts,Double.toString(A));

		// -------  B ---------------
		double ymean=0; 
		zmean=0; 
		double B=0; 
		double B2=0;
		counts=0;
		for (int y=0;y<nlines;y++) {
			value=meanCol[y];
			if ((value>=minT)&&(value<=maxT)) {
				ymean=ymean+y;
				zmean=zmean+value;
				counts++;
			}
		}
		if (counts>0) {
			ymean=ymean/counts;
			zmean=zmean/counts;
			for (int y=0;y<nlines;y++) {
				value=meanCol[y];
				if ((value>=minT)&&(value<=maxT)) {
					B=B+(y-ymean)*(value-zmean);
					B2=B2+((y-ymean)*(y-ymean));
				}
			}
			if (B2 !=0) {
				B=B/B2;
			}
		}
		dprint("counts, B -- "+counts,Double.toString(B));
		// now subtract the mean Plane from the original image
		for (int y=0;y<nlines;y++) {
			planey=B*y;
			for (int x=0;x<npoints;x++) {
				plane=planey+A*x;
				z=ip.getPixelValue(x, y);
				ip.putPixelValue(x, y, z-plane);
			}	
		}
		image.updateAndRepaintWindow();
	}


	void dprint(String arg1, String arg2){
		if (de_bug){
			IJ.log("*"+arg1+"*    *"+arg2+"*");
		}
	}

	
}
