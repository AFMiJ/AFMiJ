/* Copyright 2022 Lorenzo Lunelli

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License. */


// v 0.1 27-01-2020

import ij.*;
import ij.process.*;
import ij.plugin.*;
import java.lang.reflect.Array;

public class AFM_Undo implements PlugIn {
	
	static float [] undo_data = null;
	static Integer undo_id = 0;
	static Integer undo_slice=0;

	public void run(String arg) {
		ImagePlus imp = WindowManager.getCurrentImage();
		if (imp != null) {
			if (imp.getType() == ImagePlus.GRAY32) {
				ImageProcessor ip = imp.getProcessor();
				if (arg.equals("") && IJ.macroRunning() ) {
					if (Macro.getOptions() != null ) arg = Macro.getOptions();
				}
				if (arg.trim().equals("store")) {
					undo_data=(float[])ip.getPixelsCopy();
					undo_id = imp.getID();
					undo_slice = imp.getSlice();
				} else if (arg.equals("")) {   // no passed parameters means UNDO
					// here we exchange the undo and the image data 
					if (undo_data!=null) {
						if (undo_data.length > 0) {
							Integer current_id = imp.getID();
							//Integer current_id = ip.hashCode();
							Integer current_slice = imp.getSlice();
							if (current_id.equals(undo_id) && current_slice.equals(undo_slice)){
								float [] image_data = (float[])ip.getPixels();  // get the image pixel data
								float [] buffer_data=(float[])ip.getPixelsCopy();	// create a copy of image data
								System.arraycopy(undo_data, 0, image_data, 0, Array.getLength(image_data)); // put undo data into the image
								System.arraycopy(buffer_data, 0, undo_data, 0, Array.getLength(undo_data)); // put image data in to the undo array 
							}
						imp.updateAndDraw();
						}
					}
				}
			}
		}
	}
}
