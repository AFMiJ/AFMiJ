import java.io.BufferedReader;
import java.io.IOException;
import java.net.*; // URISyntaxException
import java.io.File;
import java.io.FileReader;
//import javax.swing.*; // uncomment to show popup messages

public class AFMiJJavalauncher  {
	public static void main(String[] args) {
		String javaoptions = "";
		String localPath = "";
		try {
			String currentPath = new java.io.File(".").getCanonicalPath();
			//JOptionPane.showMessageDialog(null,"Current dir:" + currentPath,"PopUp Dialog", JOptionPane.INFORMATION_MESSAGE);
				} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			localPath = new File(AFMiJJavalauncher.class.getProtectionDomain().getCodeSource().getLocation().toURI()).getParent();
			//JOptionPane.showMessageDialog(null,"Local dir:" + localPath,"PopUp Dialog", JOptionPane.INFORMATION_MESSAGE);
		 } catch (URISyntaxException e) {
		e.printStackTrace();
		}
		File jofile = new File(localPath + File.separator + "plugins" + File.separator + "AFMiJ" + File.separator + "storage" + File.separator + "envvars" + File.separator + "JavaOptions"); 
		try {
			BufferedReader jobr = new BufferedReader(new FileReader(jofile));
			javaoptions=jobr.readLine();
		} catch (IOException e) {
			e.printStackTrace();
		}
		String ixcommand_a = "cd "+ localPath + ";java -splash:plugins" + File.separator + "AFMiJ" + File.separator + "storage" + File.separator + "images" + File.separator + "icon.png -cp ij.jar ";
		String wincommand_a = "cd " + localPath + " & " +"java -splash:plugins" + File.separator + "AFMiJ" + File.separator + "storage" + File.separator + "images" + File.separator + "icon.png -cp ij.jar ";
		String command_b = " ij.ImageJ";
		String ixcommand = (ixcommand_a + javaoptions + command_b);
		String wincommand = (wincommand_a + javaoptions + command_b);
		try {
			String currentOS=System.getProperty("os.name");
			//JOptionPane.showMessageDialog(null,"Current OS:" + currentOS,"PopUp Dialog", JOptionPane.INFORMATION_MESSAGE);
			if (currentOS.startsWith("Mac") || currentOS.startsWith("Linux")) {
				Process process = Runtime.getRuntime().exec(new String[] {System.getenv("SHELL"), "-lc", ixcommand});
			} else if (currentOS.startsWith("Windows")) {
				Process process = Runtime.getRuntime().exec("cmd /c " + wincommand, null, null);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
