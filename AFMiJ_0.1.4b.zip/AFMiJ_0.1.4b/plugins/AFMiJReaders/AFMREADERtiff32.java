/* Copyright 2022 Lorenzo Lunelli

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License. */


//----------------------------------------------------------------------
// ----------------- TIFF 32 bits reader -------------------------------
//	v 0.4.0  4-07-2015 java conversion of jython version
//	v 0.4.1 16-12-2018 implemented as AFM reader plugin
//	v 0.4.2 01-09-2020 addedd Getversion method
//  v 0.4.3 02-09-2020 changed return codes to int
//  v 0.4.3a 20-03-2022 changed initial value of done to -1
// Lorenzo Lunelli
// passed parameters: file path, LUT dir, LUT name, lbl
//
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.lang.Math;

import ij.IJ;
import ij.ImagePlus;
import ij.ImageStack;
import ij.io.OpenDialog;
import ij.io.FileInfo;
import ij.io.FileOpener;
import ij.io.Opener;
import ij.plugin.PlugIn;
import ij.process.ImageProcessor;
import ij.process.LUT;
import ij.Macro;
import ij.measure.Calibration;


public class AFMREADERtiff32 {

	static FileInputStream fis = null;
	// ============  debug ===============
	static boolean de_bug = IJ.debugMode;
	// ============  debug ===============


	public static String Getversion() {
		String version="0.4.3a";
		return version;
	}


	public static int AFMiJread(String path,String lutdir,String lut,String lbl) {
		String known_formats,directory;
		String requires_version = "1.49v";
		String format=null;
		String sdatablock=null;
		int index=0;
		int done = -1;
		
		boolean failure = IJ.versionLessThan(requires_version);
		if (failure) {
			return done;
		}
		
		// ============  debug ===============
		de_bug = IJ.debugMode;
		// ============  debug ===============

		dprint("**** Hello **** ", " This is the TIFF 32 bits Reader plugin.");
		known_formats="Xmipp (xmp)";

		if (de_bug){
			IJ.log("*"+path+"*\n");
			IJ.log("*"+lutdir+"*\n");
			IJ.log("*"+lut+"*\n");
			IJ.log("*"+lbl+"*\n");
		}

		if (path.equals("")) {
			try {
				OpenDialog od = new OpenDialog("Choose a "+ known_formats+ " file", null);
				directory = od.getDirectory();
				path=directory + od.getFileName();
			} catch(Exception e) {done=-1;return done;};
		}
		if (lut.equals("")) {lut="None";};

		byte[] datablock =  fileread(path,1024);
		if (datablock==null){
			return done;
		}
		try {
			sdatablock = new String(datablock, "US-ASCII");
		} catch (UnsupportedEncodingException e) {
		}
		dprint("^^^ trying to find the right format ... ^^^",known_formats);
		dprint("read string length is:",Integer.toString(sdatablock.length()));
		dprint("read string is",sdatablock);
		//------------------ TIFF format ----------------------------------------
		String little_i = new String(new char [] {0x49,0x49,0x2A,0x00});  // build a char array, then transform into a string 
		String big_i = new String(new char [] {0x4D,0x4D,0x00,0x2A});	// the same
		dprint(little_i,big_i);
		if (sdatablock.startsWith(little_i) || sdatablock.startsWith(big_i)){ // tiff file
     		format="tiff";
     		ImagePlus imp = IJ.openImage(path);
			if (!lut.equals("None")){			// set the LUT
				LUT ijlut = Opener.openLut(lutdir+lut); 
				imp.getProcessor().setLut(ijlut);
			}
			ImageStack stack = imp.getImageStack();
     		int ns=imp.getImageStackSize();
			if (ns>1) {	// it's a stack
				dprint ("stack with "+ns+" slices","");
				for (index=0;index<ns;index++){
					if (lbl.equals("lbl") && (stack.getSliceLabel(index+1).contains("Height"))){
						AUTOLBL(imp,index+1);
					}
				}
			} else {	// not a stack
					if (lbl.equals("lbl")){
						AUTOLBL(imp,index+1);
					}
			}
			imp.show();
			//-----------------------------------------------------------------------
			done = 1;
		}
		else {
			done=-1;
		}
		//dprint("format=",format)
	//	if (format==null){
    //		IJ.showMessage("ERROR","file:\n--- "+path+" ---\nnot recognized !");
	//	}
		return done;
	} // ********************** END READ ***********************************


	// ========================= FUNCTIONS =============================
	//
	//
	//
	static void AUTOLBL (ImagePlus imp, int slice){
	//   v 0.4.0 12-7-2015 java conversion of jython  # v 0.3.1 24-5-2013 - modified to handle stacks	
		int nlines,npoints,stacksize;
		float mean;
		float [] data=null;
		float[] pix;
		ImageProcessor ip=null;			// define here the image structures 
		ImageStack stack =null;
		
		dprint("in autolbl plugins","");
		dprint ("slice is:",Integer.toString(slice));
		nlines=imp.getHeight();
		dprint ("nlines=",Integer.toString(nlines));
		npoints= imp.getWidth();
		dprint ("npoints=",Integer.toString(npoints));
		stacksize = imp.getImageStackSize();
		dprint("INFO slice is "+slice,", stack size is "+stacksize );
		if (slice>stacksize){
			IJ.log("error slice is "+slice+", stack size is "+stacksize);
			return;
		}
		if (stacksize==1) {   // no stack
			ip = imp.getProcessor();
			dprint("acquiring data from no stack","");
		} else {
			stack = imp.getImageStack();		// stack
			ip = stack.getProcessor(slice);
			dprint("acquiring data from stack size=",Integer.toString(stacksize));
		}
		for (int y=0;y<nlines;y++){
			mean=0;
			data = ip.getRow(0, y, data, npoints);
			for (int x=0;x<data.length;x++){
				mean=mean+data[x];
			}
			mean=mean/npoints;
			for (int x=0;x<data.length;x++){
				data[x]=data[x]-mean;
			}
			ip.putRow(0, y, data, npoints);
		}
	}


	static void dprint(String arg1, String arg2){
		if (de_bug){
			IJ.log("*"+arg1+"*    *"+arg2+"*");
		}
	}


	static byte[] fileread(String InputFileName, int numbytes){   // numbytes=0 means to the end of the file, if numbytes exceeds the file length, the file is read to the end.
		FileInputStream fis = null;
		byte[] buf = null;
		int length;
      	try {
			try {
				fis = new FileInputStream(InputFileName);
				length = Math.min(fis.available(),numbytes);
				if (numbytes==0){
					length=fis.available();
				}
				dprint("bytes to read are: ",Integer.toString(length));
				buf = new byte[length];
				fis.read(buf);
			}
			finally {
				// releases all system resources from the streams
				if(fis!=null) {
            		fis.close();
				}
			}
		}
    	catch(FileNotFoundException ex){
    	}
    	catch(IOException ex){
    	}
		return buf;
	}
}
